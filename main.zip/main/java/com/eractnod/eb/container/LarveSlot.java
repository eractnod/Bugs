package com.eractnod.eb.container;

import com.eractnod.eb.ediblebugs.common.EBVarInit;

import net.minecraft.block.Block;
import net.minecraft.block.BlockDirt;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class LarveSlot extends Slot {

	public LarveSlot(IInventory inventoryIn, int index, int xPosition, int yPosition) {
		super(inventoryIn, index, xPosition, yPosition);
		// TODO Auto-generated constructor stub
	}

    /**
     * Check if the stack is a valid item for this slot. Always true beside for the armor slots.
     */
    public boolean isItemValid(ItemStack itemStack)
    {
    	if(itemStack == null){
    		return false;
    	}
        return (itemStack.getItem() == EBVarInit.termiteLarva);
    }
    
}
