package com.eractnod.eb.container;

import com.eractnod.eb.ediblebugs.tileentity.TileEntityBugZapper;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class ContainerBugZapper extends Container{

	private TileEntityBugZapper bugZapper;
	private int slotCount = 0;
	
	public ContainerBugZapper(InventoryPlayer inventory, TileEntityBugZapper tile_entity) {
		
		this.bugZapper = tile_entity;
		int i;
       for (i = 0; i < 2; ++i)
        {
            for (int j = 0; j < 2; ++j)
            {
                this.addSlotToContainer(new DirtSlot(tile_entity, slotCount++, 16 + j * 18, 25 + i * 18));
            }
        }
       for (i = 0; i < 2; ++i)
        {
            for (int j = 0; j < 2; ++j)
            {
                this.addSlotToContainer(new LarveSlot(tile_entity, slotCount++, 126 + j * 18, 25 + i * 18));
            }
        }
       for (i = 0; i < 3; ++i)
        {
            for (int j = 0; j < 3; ++j)
            {
                this.addSlotToContainer(new Slot(tile_entity, slotCount++, 62 + j * 18, 17 + i * 18));
            }
        }

        for (i = 0; i < 3; ++i)
        {
            for (int j = 0; j < 9; ++j)
            {
                this.addSlotToContainer(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }

        for (i = 0; i < 9; ++i)
        {
            this.addSlotToContainer(new Slot(inventory, i, 8 + i * 18, 142));
        }
	}

	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		return this.bugZapper.isUsableByPlayer(playerIn);
	}

	@Override
    public ItemStack transferStackInSlot(EntityPlayer par1EntityPlayer, int index)
    {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = (Slot)this.inventorySlots.get(index);

        if (slot != null && slot.getHasStack())
        {
            ItemStack itemstack1 = slot.getStack();
            itemstack = itemstack1.copy();

            if (index > 7 && index < 17)
            {
                if (!this.mergeItemStack(itemstack1, 17, 44, true))
                {
                	return ItemStack.EMPTY;
                }

                slot.onSlotChange(itemstack1, itemstack);
            }
            else if (index > 16 && index < 44){
            	if (!this.mergeItemStack(itemstack1, 0, 8, true)){
            		return ItemStack.EMPTY;
            	}
            }
             else if (!this.mergeItemStack(itemstack1, 17, 44, false))
            {
            	 return ItemStack.EMPTY;
            }

            if (itemstack1.getCount() == 0)
            {
                slot.putStack(ItemStack.EMPTY);
            }
            else
            {
                slot.onSlotChanged();
            }

            if (itemstack1.getCount() == itemstack.getCount())
            {
            	return ItemStack.EMPTY;
            }

            slot.onTake(par1EntityPlayer, itemstack1);
        }

        return itemstack;
    }
}
