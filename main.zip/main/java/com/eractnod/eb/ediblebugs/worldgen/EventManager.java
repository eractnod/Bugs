package com.eractnod.eb.ediblebugs.worldgen;

import java.util.Random;

import com.eractnod.eb.ediblebugs.common.EBVarInit;

import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.fml.common.IWorldGenerator;

public class EventManager implements IWorldGenerator{

	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, net.minecraft.world.gen.IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {	
		switch (world.provider.getDimension()) {
		
		case -1: generateNether(world, random, chunkX * 16, chunkZ * 16);
		case 0: generateSurface(world, random, chunkX * 16, chunkZ * 16);
		case 1: generateEnd(world, random, chunkX * 16, chunkZ * 16);
		
		}
		
	}

	private void generateSurface(World world, Random random, int x, int z) {
		boolean notAVoid = false;
		int savannaRand = random.nextInt(EBVarInit.savannaChance);
		int forestRand = random.nextInt(EBVarInit.forestChance);
		Biome biomeGenBase = world.getBiomeForCoordsBody(new BlockPos(x, 70, z));
		if(biomeGenBase == Biomes.SAVANNA || biomeGenBase == Biomes.SAVANNA_PLATEAU){
			if (savannaRand == 0 || savannaRand == 10){
				int Xcoord1 = x + random.nextInt(16); //where in chuck it generates
				int Ycoord1 = random.nextInt(110 - 60) + 60; //how high it generates
				int Zcoord1 = z + random.nextInt(16); //where in chunk it generates
				
				for (int testAir = -20; testAir < 1; testAir++){
					if(world.getBlockState(new BlockPos(Xcoord1, Ycoord1 + testAir, Zcoord1)).getBlock() != Blocks.AIR){
						notAVoid = true;
					}
				}
				if(notAVoid){
					new TermiteMoundGen(10).generate(world, random, new BlockPos(Xcoord1, Ycoord1, Zcoord1));
					notAVoid = false;
				}
			}	
		}
		
		if(biomeGenBase == Biomes.FOREST || biomeGenBase == Biomes.FOREST_HILLS){
			if (forestRand == 5){
				
				int Xcoord1 = x + random.nextInt(16); //where in chuck it generates
				int Ycoord1 = random.nextInt(75 - 60) + 60; //how high it generates
				int Zcoord1 = z + random.nextInt(16); //where in chunk it generates
				for (int testAir = -20; testAir < 1; testAir++){
					if(world.getBlockState(new BlockPos(Xcoord1, Ycoord1 + testAir, Zcoord1)).getBlock() != Blocks.AIR){
						notAVoid = true;
					}
				}
				if(notAVoid){
					new TermiteMoundGen(10).generate(world, random, new BlockPos(Xcoord1, Ycoord1, Zcoord1));
				}
			}	
		}
	}
	

	private void generateNether(World world, Random random, int x, int z) {
	
	}

	
	private void generateEnd(World world, Random random, int x, int z) {
	
		
	}
	
}
