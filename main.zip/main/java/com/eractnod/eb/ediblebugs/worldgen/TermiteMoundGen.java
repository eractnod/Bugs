package com.eractnod.eb.ediblebugs.worldgen;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

import com.eractnod.eb.ediblebugs.blocks.TermiteBlockClass;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class TermiteMoundGen extends WorldGenerator
{
    private Block usedBlock;
    /** The number of blocks to generate. */
    private int numberOfBlocks;
    private int moundGround = 0;

    public TermiteMoundGen(int numBlocks)
    {
        this.usedBlock = EBVarInit.termiteBlock;
        this.numberOfBlocks = numBlocks;
    }

    @Override
    public boolean generate(World world, Random rand, BlockPos pos)
    {
    	int moundHeight = rand.nextInt(3) + 2;
    	boolean flag = true;
    	
    	if (pos.getY() >= 1 && pos.getY() + moundHeight + 1 <= 256){
    		
    	
	    	//Find top block
	    	for (int firstGround = 60; firstGround < 250 && flag; firstGround++){
	    		
	    		Block block = world.getBlockState(new BlockPos(pos.getX(), firstGround, pos.getZ())).getBlock();
	    		IBlockState blockstate = world.getBlockState(new BlockPos(pos.getX(), firstGround, pos.getZ()));
	    		Block block1 = world.getBlockState(new BlockPos(pos.getX(), firstGround - 1, pos.getZ())).getBlock();
	    		IBlockState blockstate1 = world.getBlockState(new BlockPos(pos.getX(), firstGround - 1, pos.getZ()));
	    		
	    		if (blockstate.getMaterial() == Material.WATER || blockstate.getMaterial() == Material.SAND){
	    			flag = false;
	    		}else{
		    		if (block.isAir(blockstate, world, new BlockPos(pos.getZ(), firstGround, pos.getZ())))
		    		{
			    		if (blockstate1.getMaterial() == Material.GRASS || blockstate1.getMaterial() == Material.VINE || block1 == Blocks.DIRT || block1 == Blocks.GRASS);
			    		{
			    			
			    			moundGround = firstGround - 1;
		    				flag = false;
			    			
			    		}
		    		}
	    		}
	    	}
	  
	    	for (int count = 0; count <= moundHeight; count++)
	    	{
	    		Block block = world.getBlockState(new BlockPos(pos.getX(), moundGround + count, pos.getZ())).getBlock();
	    		IBlockState blockstate = world.getBlockState(new BlockPos(pos.getX(), moundGround + count, pos.getZ()));
    			if(block.isAir(blockstate, world, new BlockPos(pos.getX(), moundGround + count, pos.getZ())))
    			{
    				world.setBlockState(new BlockPos(pos.getX(), moundGround, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX(), moundGround + count, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX(), moundGround, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX(), moundGround, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
        			
    				world.setBlockState(new BlockPos(pos.getX(), moundGround + 1, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX(), moundGround + 1, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround + 1, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround + 1, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
        			
    				world.setBlockState(new BlockPos(pos.getX(), moundGround - 1, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround - 1, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround - 1, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() + 1, moundGround - 1, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround - 1, pos.getZ()), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround - 1, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX() - 1, moundGround - 1, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX(), moundGround - 1, pos.getZ() + 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
    				world.setBlockState(new BlockPos(pos.getX(), moundGround - 1, pos.getZ() - 1), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
        	
        		}
	    	}
	    	return true;
    	}
    	return false;
    }

}