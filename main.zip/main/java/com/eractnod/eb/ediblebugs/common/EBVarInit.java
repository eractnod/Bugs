package com.eractnod.eb.ediblebugs.common;

import java.util.ArrayList;
import java.util.List;

import com.eractnod.eb.ediblebugs.blocks.BlockEBSlab;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;

public class EBVarInit {
	
	//Blocks
	public static Block termiteBlock;
	public static ItemBlock termiteBlockItem;
	
	//Machines
	public static Block EBfryerIdle;
	public static Block EBfryerActive;
	public static final int guiIDFryer = 0;
	public static ItemBlock EBfryerIdleItem;
	public static ItemBlock EBfryerActiveItem;
	
	
	//Items
	public static Item termite;
	public static Item termiteLarva;
	
	public static Item grassBugs;
	public static Item woodBugs;
	public static Item dirtBugs;
	public static Item sandBugs;
	
	public static Item vegetableoil;
	
	public static Item cookedBugs;
	
	//Config Items
	public static boolean grassBugsEnable = true;
	public static boolean woodBugsEnable = true;
	public static boolean dirtBugsEnable = true;
	public static boolean sandBugsEnable = true;
	public static int savannaChance = 10;
	public static int forestChance = 30;
	
	public static int grassBugsDropRate = 20;
	public static int woodBugsDropRate = 20;
	public static int dirtBugsDropRate = 20;
	public static int sandBugsDropRate = 20;
	
	public static List<String> itemList = new ArrayList<String>();
	public static List<String> blockList = new ArrayList<String>();
	
	public static int chanceLarva;
	
	public static float woodSat = 0.5F;
	public static float dirtSat = 0.5F;
	public static float grassSat = 0.5F;
	public static float sandSat = 0.5F;
	public static float cookedSat = 2.0F;
	
	public static int woodRepl = 2;
	public static int dirtRepl = 2;
	public static int grassRepl = 2;
	public static int sandRepl = 2;
	public static int cookedRepl = 6;
	
	public static Block bugZapper;
	public static ItemBlock bugZapperItem;
	public static int moundGrowth = 4;
	public static final int guiIDBugZapper = 1;
	
	public static Item termiteClay;
	public static Item termiteBrick;
	public static Block termiteBricks;
	public static ItemBlock termiteBricksItem;
	
	public static Block ebTermiteStair;
	public static BlockEBSlab ebSlabS;
	public static BlockEBSlab ebSlabD;
	public static ItemBlock ebTermiteStairItem;
	public static ItemBlock ebSlabSItem;
	public static ItemBlock ebSlabDItem;
	
}
