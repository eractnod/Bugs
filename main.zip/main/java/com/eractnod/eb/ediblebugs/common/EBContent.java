package com.eractnod.eb.ediblebugs.common;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.OreDictionary;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.blocks.BlockBugZapperClass;
import com.eractnod.eb.ediblebugs.blocks.BlockEBSlab;
import com.eractnod.eb.ediblebugs.blocks.BlockEBSlabDouble;
import com.eractnod.eb.ediblebugs.blocks.BlockEBStairs;
import com.eractnod.eb.ediblebugs.blocks.TermiteBlockClass;
import com.eractnod.eb.ediblebugs.blocks.TermiteBricksClass;
import com.eractnod.eb.ediblebugs.itemblock.ItemBlockBugZapper;
import com.eractnod.eb.ediblebugs.itemblock.ItemBlockEBSlab;
import com.eractnod.eb.ediblebugs.itemblock.ItemBlockTermiteMound;
import com.eractnod.eb.ediblebugs.items.EBCookedBugsItemClass;
import com.eractnod.eb.ediblebugs.items.EBDirtBugsItemClass;
import com.eractnod.eb.ediblebugs.items.EBFoodItemClass;
import com.eractnod.eb.ediblebugs.items.EBGrassBugsItemClass;
import com.eractnod.eb.ediblebugs.items.EBSandBugsItemClass;
import com.eractnod.eb.ediblebugs.items.EBTermiteItem;
import com.eractnod.eb.ediblebugs.items.EBTermiteLarvaItemClass;
import com.eractnod.eb.ediblebugs.items.EBVegetableOilItemClass;
import com.eractnod.eb.ediblebugs.items.EBWoodBugsItemClass;
import com.eractnod.eb.ediblebugs.machines.EBFryerClass;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityBugZapper;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityEBFryer;

public class EBContent {
	
	public EBContent(){
		registerBlocks();
		registerItems();
		gameRegistry();
		registerTileEntities();

	}

	void registerBlocks() {
		
		EBVarInit.termiteBlock = new TermiteBlockClass(Material.GROUND, "termiteblock", .75F, 1.0F);
		EBVarInit.termiteBlockItem = new ItemBlockTermiteMound(EBVarInit.termiteBlock);
		
		EBVarInit.EBfryerActive = new EBFryerClass(true).setUnlocalizedName("ebfryeractive").setLightLevel(0.875F);
		EBVarInit.EBfryerIdle = new EBFryerClass(false).setUnlocalizedName("ebfryeridle").setCreativeTab(EdibleBugs.tabEdibleBugs);
		EBVarInit.EBfryerIdleItem = new ItemBlock(EBVarInit.EBfryerIdle);
		EBVarInit.EBfryerActiveItem = new ItemBlock(EBVarInit.EBfryerActive);
		
		EBVarInit.bugZapper = new BlockBugZapperClass(Material.GROUND);
		EBVarInit.bugZapperItem = new ItemBlockBugZapper(EBVarInit.bugZapper);
		ForgeRegistries.BLOCKS.register(EBVarInit.bugZapper.setRegistryName("bugzapper"));
		ForgeRegistries.ITEMS.register(EBVarInit.bugZapperItem.setRegistryName(EBVarInit.bugZapper.getRegistryName()));
		EBVarInit.bugZapper.setUnlocalizedName(EBVarInit.bugZapper.getRegistryName().toString());

		EBVarInit.termiteBricks = new TermiteBricksClass(Material.ROCK, 2.0F, 10.0F);
		EBVarInit.termiteBricksItem = new ItemBlock(EBVarInit.termiteBricks);
	    EBVarInit.ebTermiteStair = new BlockEBStairs(EBVarInit.termiteBricks, EBVarInit.termiteBricks.getDefaultState(), 2.0f, 10.0f, SoundType.STONE);
	    EBVarInit.ebTermiteStairItem= new ItemBlock(EBVarInit.ebTermiteStair);

	    EBVarInit.ebSlabS = new BlockEBSlab(Material.ROCK, "ebslabs", 2.0f, 10.0F);
	    EBVarInit.ebSlabD = new BlockEBSlabDouble(Material.ROCK, "ebslabd", 2.0f, 10.0F);
	    EBVarInit.ebSlabSItem = new ItemBlockEBSlab(EBVarInit.ebSlabS, EBVarInit.ebSlabS, EBVarInit.ebSlabD);


	}

	void registerItems() {
		EBVarInit.termite = new EBFoodItemClass(EBVarInit.woodRepl, EBVarInit.woodSat, false).setUnlocalizedName("termite");
		EBVarInit.termiteLarva = new EBTermiteLarvaItemClass().setUnlocalizedName("termitelarva");
		EBVarInit.grassBugs = new EBGrassBugsItemClass(EBVarInit.grassRepl, EBVarInit.grassSat, false).setUnlocalizedName("grassbugs");
		EBVarInit.woodBugs = new EBWoodBugsItemClass(EBVarInit.woodRepl, EBVarInit.woodSat, false).setUnlocalizedName("woodbugs");
		EBVarInit.dirtBugs = new EBDirtBugsItemClass(EBVarInit.dirtRepl, EBVarInit.dirtSat, false).setUnlocalizedName("dirtbugs");
		EBVarInit.sandBugs = new EBSandBugsItemClass(EBVarInit.sandRepl, EBVarInit.sandSat, false).setUnlocalizedName("sandbugs");
		
		EBVarInit.vegetableoil = new EBVegetableOilItemClass().setUnlocalizedName("vegetableoil");
		EBVarInit.cookedBugs = new EBCookedBugsItemClass(EBVarInit.cookedRepl, EBVarInit.cookedSat, false).setUnlocalizedName("cookedbugs");
		
		EBVarInit.termiteClay = new EBTermiteItem().setUnlocalizedName("termiteclay");
		EBVarInit.termiteBrick = new EBTermiteItem().setUnlocalizedName("termitebrick");
	}

	void gameRegistry() {
		//Blocks
		ForgeRegistries.BLOCKS.register(EBVarInit.termiteBlock.setRegistryName("termiteblock"));
		ForgeRegistries.ITEMS.register(EBVarInit.termiteBlockItem.setRegistryName(EBVarInit.termiteBlock.getRegistryName()));
		EBVarInit.termiteBlock.setUnlocalizedName(EBVarInit.termiteBlock.getRegistryName().toString());
		
		ForgeRegistries.BLOCKS.register(EBVarInit.EBfryerActive.setRegistryName("ebfryeractive"));
		ForgeRegistries.ITEMS.register(EBVarInit.EBfryerActiveItem.setRegistryName(EBVarInit.EBfryerActive.getRegistryName()));
		EBVarInit.EBfryerActive.setUnlocalizedName(EBVarInit.EBfryerActive.getRegistryName().toString());
		
		ForgeRegistries.BLOCKS.register(EBVarInit.EBfryerIdle.setRegistryName("ebfryeridle"));
		ForgeRegistries.ITEMS.register(EBVarInit.EBfryerIdleItem.setRegistryName(EBVarInit.EBfryerIdle.getRegistryName()));
		EBVarInit.EBfryerIdle.setUnlocalizedName(EBVarInit.EBfryerIdle.getRegistryName().toString());

		ForgeRegistries.BLOCKS.register(EBVarInit.termiteBricks.setRegistryName("termitebricks"));
		ForgeRegistries.ITEMS.register(EBVarInit.termiteBricksItem.setRegistryName(EBVarInit.termiteBricks.getRegistryName()));
		EBVarInit.termiteBricks.setUnlocalizedName(EBVarInit.termiteBricks.getRegistryName().toString());
	
		ForgeRegistries.BLOCKS.register(EBVarInit.ebTermiteStair.setRegistryName("ebtermitestair"));
		ForgeRegistries.ITEMS.register(EBVarInit.ebTermiteStairItem.setRegistryName(EBVarInit.ebTermiteStair.getRegistryName()));
		EBVarInit.ebTermiteStair.setUnlocalizedName(EBVarInit.ebTermiteStair.getRegistryName().toString());
	
		ForgeRegistries.BLOCKS.register(EBVarInit.ebSlabS.setRegistryName("ebslabs"));
		ForgeRegistries.BLOCKS.register(EBVarInit.ebSlabD.setRegistryName("ebslabd"));
		ForgeRegistries.ITEMS.register(EBVarInit.ebSlabSItem.setRegistryName(EBVarInit.ebSlabS.getRegistryName()));
		EBVarInit.ebSlabS.setUnlocalizedName(EBVarInit.ebSlabS.getRegistryName().toString());
		EBVarInit.ebSlabD.setUnlocalizedName(EBVarInit.ebSlabD.getRegistryName().toString());
		
			
		//Items
		ForgeRegistries.ITEMS.register(EBVarInit.termite.setRegistryName("termite"));
		ForgeRegistries.ITEMS.register(EBVarInit.termiteLarva.setRegistryName("termitelarva"));
		ForgeRegistries.ITEMS.register(EBVarInit.grassBugs.setRegistryName("grassbugs"));
		ForgeRegistries.ITEMS.register(EBVarInit.woodBugs.setRegistryName("woodbugs"));
		ForgeRegistries.ITEMS.register(EBVarInit.dirtBugs.setRegistryName("dirtbugs"));
		ForgeRegistries.ITEMS.register(EBVarInit.sandBugs.setRegistryName("sandbugs"));
		ForgeRegistries.ITEMS.register(EBVarInit.vegetableoil.setRegistryName("vegetableoil"));
		ForgeRegistries.ITEMS.register(EBVarInit.cookedBugs.setRegistryName("cookedbugs"));
		ForgeRegistries.ITEMS.register(EBVarInit.termiteClay.setRegistryName("termiteclay"));
		ForgeRegistries.ITEMS.register(EBVarInit.termiteBrick.setRegistryName("termitebrick"));
		OreDictionary.registerOre("clay", EBVarInit.termiteClay);
		OreDictionary.registerOre("clay", Items.CLAY_BALL);
		
	}

	void registerTileEntities() {
		GameRegistry.registerTileEntity(TileEntityEBFryer.class, "tileentityebfryer");
		GameRegistry.registerTileEntity(TileEntityBugZapper.class, "tileentitybugzapper");
	}



}
