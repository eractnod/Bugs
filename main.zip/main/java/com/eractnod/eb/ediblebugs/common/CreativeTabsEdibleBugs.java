package com.eractnod.eb.ediblebugs.common;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class CreativeTabsEdibleBugs extends CreativeTabs {

	public CreativeTabsEdibleBugs(String lable) {
		super(lable);
		
	}

	@Override
	public ItemStack getTabIconItem() {
		return new ItemStack(EBVarInit.dirtBugs);
	}

}
