package com.eractnod.eb.ediblebugs;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.eractnod.eb.ediblebugs.common.CreativeTabsEdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBContent;
import com.eractnod.eb.ediblebugs.common.EBVarInit;
import com.eractnod.eb.ediblebugs.proxy.ClientProxy;
import com.eractnod.eb.ediblebugs.recipes.EdibleBugsCrafting;
import com.eractnod.eb.ediblebugs.vanillachanges.ChangeDirtDrop;
import com.eractnod.eb.ediblebugs.worldgen.EventManager;
import com.eractnod.eb.gui.EBGuiHandler;


//Fully functioning Mod on 
//MC 1.11.2
//The real deal


@Mod(modid = EdibleBugs.MODID, name = EdibleBugs.NAME, version = EdibleBugs.VERSION)

public class EdibleBugs {

	public static final String MODID = "ediblebugs";
    public static final String NAME = "Edible Bugs Mod";
    public static final String VERSION = "1.6.2.2678";
   
    @Instance(value=MODID)
    public static EdibleBugs instance = new EdibleBugs();
    public static EBContent content;
    private EBGuiHandler ebguihandler = new EBGuiHandler();

	public static CreativeTabs tabEdibleBugs = new CreativeTabsEdibleBugs("EdibleBugs");

	//Add new world generation
    EventManager eventmanager = new EventManager();
	
	 @EventHandler
	    public void preInit(FMLPreInitializationEvent event)
	    {
		 
		content = new EBContent();
		// Configuration File
	  	Configuration Config = new Configuration(event.getSuggestedConfigurationFile());
	 		
	 	Config.load();
	 		
	 	EBVarInit.dirtBugsEnable = Config.getBoolean("Enable Dirt Bugs drop:  Default True", "Dirt Bugs Enable", true, "Enable Drops");
	 	EBVarInit.grassBugsEnable = Config.getBoolean("Enable Grass Bugs drop:  Default True", "Grass Bugs Enable", true, "Enable Drops");
	 	EBVarInit.woodBugsEnable = Config.getBoolean("Enable Wood Bugs drop:  Default True", "Wood Bugs Enable", true, "Enable Drops");
	 	EBVarInit.sandBugsEnable = Config.getBoolean("Enable Sand Bugs drop:  Default True", "Sand Bugs Enable", true, "Enable Drops");

	 	EBVarInit.dirtBugsDropRate = Config.getInt("Set drop rate of Dirt Bugs, Increase number to reduce drop rate:  Default 15", "Dirt Bugs Drop Rate", 15, 1, 50, "Drop Rate");
	 	EBVarInit.grassBugsDropRate = Config.getInt("Set drop rate of Grass Bugs, Increase number to reduce drop rate:  Default 15", "Grass Bugs Drop Rate", 15, 1, 50, "Drop Rate");
	 	EBVarInit.woodBugsDropRate = Config.getInt("Set drop rate of Wood Bugs, Increase number to reduce drop rate:  Default 15", "Wood Bugs Drop Rate", 15, 1, 50, "Drop Rate");
	 	EBVarInit.sandBugsDropRate = Config.getInt("Set drop rate of Sand Bugs, Increase number to reduce drop rate:  Default 15", "Sand Bugs Drop Rate", 15, 1, 50, "Drop Rate");
	 	EBVarInit.chanceLarva = Config.getInt("Set drop rate of Termite Larva, Increase number to reduce drop rate:  Default 10", "Larva Drop Rate", 10, 1, 50, "Drop Rate");
		
	 	EBVarInit.woodSat = Config.getFloat("Set Saturation rate of Wood Bugs", "Saturation", 0.5F, 0.1F, 1.0F, "Saturation Value");
	 	EBVarInit.dirtSat = Config.getFloat("Set Saturation rate of Dirt Bugs", "Saturation", 0.5F, 0.1F, 1.0F, "Saturation Value");
	 	EBVarInit.grassSat = Config.getFloat("Set Saturation rate of Grass Bugs", "Saturation", 0.5F, 0.1F, 1.0F, "Saturation Value");
	 	EBVarInit.sandSat = Config.getFloat("Set Saturation rate of Sand Bugs", "Saturation", 0.5F, 0.1F, 1.0F, "Saturation Value");
	 	EBVarInit.cookedSat = Config.getFloat("Set Saturation rate of Cooked Bugs", "Saturation", 2.0F, 0.1F, 1.0F, "Saturation Value");

	 	EBVarInit.woodRepl = Config.getInt("Set Replenishment(Hearts) rate of Wood Bugs", "Replenishment", 2, 1, 10, "Replenishment Value");
	 	EBVarInit.dirtRepl = Config.getInt("Set Replenishment(Hearts) rate of Dirt Bugs", "Replenishment", 2, 1, 10, "Replenishment Value");
	 	EBVarInit.grassRepl = Config.getInt("Set Replenishment(Hearts) rate of Grass Bugs", "Replenishment", 2, 1, 10, "Replenishment Value");
	 	EBVarInit.sandRepl = Config.getInt("Set Replenishment(Hearts) rate of Sand Bugs", "Replenishment", 2, 1, 10, "Replenishment Value");
	 	EBVarInit.cookedRepl = Config.getInt("Set Replenishment(Hearts) rate of Cooked Bugs", "Replenishment", 6, 1, 10, "Replenishment Value");

	 	EBVarInit.moundGrowth = Config.getInt("Set Termite Mound growth rate", "Growth", 4, 1, 10, "Termite Mound Growth Value");
	 	EBVarInit.savannaChance = Config.getInt("Chance of Termite Mounds in Savanna. Higher number less chance", "Chance", 10, 1, 100, "Termite Mound Spawn Chance");
	 	EBVarInit.forestChance = Config.getInt("Chance of Termite Mounds in Forest. Higher number less chance", "Chance", 30, 1, 100, "Termite Mound Spawn Chance");

	 	Config.save();
	         	
		 	
	 	if(FMLCommonHandler.instance().getSide().isClient()) ClientProxy.preInit();
	    	
		// Add world generation
	    GameRegistry.registerWorldGenerator(eventmanager, 0);
        
	    }
	 
	 
	 @EventHandler
	    public void init(FMLInitializationEvent event)
	    {
		 if(FMLCommonHandler.instance().getSide().isClient()) ClientProxy.init();
		 	MinecraftForge.EVENT_BUS.register(new ChangeDirtDrop());
		 	
		 	NetworkRegistry.INSTANCE.registerGuiHandler(instance, ebguihandler);
		 	EdibleBugsCrafting.addRecipes();
		 	
	
	    }
	 
	 @EventHandler 
		public void postInit(FMLPostInitializationEvent event)
		{
			 
		}
}
