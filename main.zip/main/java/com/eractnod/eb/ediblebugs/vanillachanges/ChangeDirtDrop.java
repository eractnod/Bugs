package com.eractnod.eb.ediblebugs.vanillachanges;

import java.util.Random;

import net.minecraft.block.BlockDirt;
import net.minecraft.block.BlockGrass;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockSand;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class ChangeDirtDrop {
	Random rand = new Random();
	
	@SubscribeEvent
    public void onBlockEvent(HarvestDropsEvent event){
		
		//Dirt drops
		if (event.getState().getBlock() instanceof BlockDirt && EBVarInit.dirtBugsEnable){
			if (rand.nextInt(EBVarInit.dirtBugsDropRate) == 0){
				int whichDirtBug = rand.nextInt(4);
				switch (whichDirtBug)
				{
				case 0:
					event.getDrops().add(new ItemStack(EBVarInit.dirtBugs, 1, 0));
					event.setDropChance(1.0F);
					break;
				case 1:
					event.getDrops().add(new ItemStack(EBVarInit.dirtBugs, 1, 1));
					event.setDropChance(1.0F);
					break;
				case 2:
					event.getDrops().add(new ItemStack(EBVarInit.dirtBugs, 1, 2));
					event.setDropChance(1.0F);
					break;
				case 3:
					event.getDrops().add(new ItemStack(EBVarInit.dirtBugs, 1, 3));
					event.setDropChance(1.0F);
					break;
				}
			}
		}
		
		//Grass drops
		if (event.getState().getBlock() instanceof BlockGrass && EBVarInit.grassBugsEnable){
			if (rand.nextInt(EBVarInit.grassBugsDropRate) == 0){
				int whichGrassBug = rand.nextInt(4);
				switch (whichGrassBug)
				{
				case 0:
					event.getDrops().add(new ItemStack(EBVarInit.grassBugs, 1, 0));
					event.setDropChance(1.0F);
					break;
				case 1:
					event.getDrops().add(new ItemStack(EBVarInit.grassBugs, 1, 1));
					event.setDropChance(1.0F);
					break;
				case 2:
					event.getDrops().add(new ItemStack(EBVarInit.grassBugs, 1, 2));
					event.setDropChance(1.0F);
					break;
				case 3:
					event.getDrops().add(new ItemStack(EBVarInit.grassBugs, 1, 3));
					event.setDropChance(1.0F);
					break;
				}
			}
		}

		//Wood drops
		if (event.getState().getBlock() instanceof BlockLog && EBVarInit.woodBugsEnable){
			if (rand.nextInt(EBVarInit.woodBugsDropRate) == 0){
				int whichWoodBug = rand.nextInt(4);
				switch (whichWoodBug)
				{
				case 0:
					event.getDrops().add(new ItemStack(EBVarInit.woodBugs, 1, 0));
					event.setDropChance(1.0F);
					break;
				case 1:
					event.getDrops().add(new ItemStack(EBVarInit.woodBugs, 1, 1));
					event.setDropChance(1.0F);
					break;
				case 2:
					event.getDrops().add(new ItemStack(EBVarInit.woodBugs, 1, 2));
					event.setDropChance(1.0F);
					break;
				case 3:
					event.getDrops().add(new ItemStack(EBVarInit.woodBugs, 1, 3));
					event.setDropChance(1.0F);
					break;
				}
			}
		}
		
		//Sand Drops
		if (event.getState().getBlock() instanceof BlockSand && EBVarInit.sandBugsEnable){
			if (rand.nextInt(EBVarInit.sandBugsDropRate) == 0){
				int whichsandBug = rand.nextInt(4);
				switch (whichsandBug)
				{
				case 0:
					event.getDrops().add(new ItemStack(EBVarInit.sandBugs, 1, 0));
					event.setDropChance(1.0F);
					break;
				case 1:
					event.getDrops().add(new ItemStack(EBVarInit.sandBugs, 1, 1));
					event.setDropChance(1.0F);
					break;
				case 2:
					event.getDrops().add(new ItemStack(EBVarInit.sandBugs, 1, 2));
					event.setDropChance(1.0F);
					break;
				case 3:
					event.getDrops().add(new ItemStack(EBVarInit.sandBugs, 1, 3));
					event.setDropChance(1.0F);
					break;
				}
			}
		}
	}

}
