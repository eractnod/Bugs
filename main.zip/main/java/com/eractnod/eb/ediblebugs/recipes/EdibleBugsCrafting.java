package com.eractnod.eb.ediblebugs.recipes;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.oredict.OreDictionary;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class EdibleBugsCrafting 
{
	public static void addRecipes() 
	{

		//Use this to create the JSON file for the recipe.  Will be in the run folder under changeme directory.
		//Just move the file to the assets/recipes folder
		/*
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.WHEAT_SEEDS, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.MELON_SEEDS, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.PUMPKIN_SEEDS, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.CARROT, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.POTATO, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.BEETROOT, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.vegetableoil, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(Items.BEETROOT_SEEDS, 1, 0))});
		
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.EBfryerIdle, 1, 0), new Object[]{"RRR", "ROR", "RRR", 'R', Items.IRON_INGOT, 'O', (new ItemStack(EBVarInit.vegetableoil))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.bugZapper, 1, 0), new Object[]{"ITI", "GFG", "IRI", 'I', Items.IRON_INGOT, 'G', Items.GOLDEN_SHOVEL, 'F', Blocks.FURNACE, 'R', Items.REDSTONE, 'T', (new ItemStack(EBVarInit.termite))});

		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.termiteBricks, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(EBVarInit.termiteBrick, 1, 0))});

		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.ebSlabS, 6, 0), new Object[]{"RRR", 'R', (new ItemStack(EBVarInit.termiteBricks, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.ebTermiteStair, 4, 0), new Object[]{"R  ", "RR ", "RRR", 'R', (new ItemStack(EBVarInit.termiteBricks, 1, 0))});
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.termiteBricks, 1, 0), new Object[]{"R  ", "R  ", 'R', (new ItemStack(EBVarInit.ebSlabS, 1, 0))});
				
		RecipeJsonCreate.addShapedRecipe(new ItemStack(EBVarInit.termiteBricks, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(EBVarInit.termiteBrick, 1, 0))});
*/		
		GameRegistry.addShapedRecipe(new ResourceLocation("ediblebugs:clayblock"), null, new ItemStack(Blocks.CLAY, 1, 0), new Object[]{"RR ", "RR ", 'R', (new ItemStack(EBVarInit.termiteClay, 1, 0))});

		for(ItemStack s : OreDictionary.getOres("clay"))
		{
			FurnaceRecipes.instance().addSmeltingRecipe(s, new ItemStack(Items.BRICK), 0.1F);	
		}

	}


	
}
