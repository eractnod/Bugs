package com.eractnod.eb.ediblebugs.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import com.eractnod.eb.ediblebugs.common.EBVarInit;
import com.eractnod.eb.ediblebugs.machines.EBFryerClass;
import com.eractnod.eb.ediblebugs.recipes.FryerRecipes;

public class TileEntityEBFryer extends TileEntity implements ITickable, ISidedInventory
{
    private static final int[] slots_top = new int[] {0};
    private static final int[] slots_bottom = new int[] {2, 1};
    private static final int[] slots_sides = new int[] {1};

    /**
     * The ItemStacks that hold the items currently being used in the furnace
     */
    //private ItemStack[] fryerItemStacks = new ItemStack[3];
    private NonNullList<ItemStack> fryerItemStacks = NonNullList.<ItemStack>withSize(3, ItemStack.EMPTY);

    /** The number of ticks that the furnace will keep burning */
    public int fryerBurnTime;

    /**
     * The number of ticks that a fresh copy of the currently-burning item would keep the furnace burning for
     */
    public int currentItemBurnTime;

    /** The number of ticks that the current item has been cooking for */
    public int fryerCookTime;
    private String displayName;

    /**
     * Returns the number of slots in the inventory.
     */
    public int getSizeInventory()
    {
        return this.fryerItemStacks.size();
    }

    /**
     * Returns the stack in slot i
     */
    public ItemStack getStackInSlot(int par1)
    {
        return (ItemStack)this.fryerItemStacks.get(par1);
    }

    /**
     * Removes from an inventory slot (first arg) up to a specified number (second arg) of items and returns them in a
     * new stack.
     */
    public ItemStack decrStackSize(int index, int count)
    {
        return ItemStackHelper.getAndSplit(this.fryerItemStacks, index, count);
    }

    /**
     * When some containers are closed they call this on each slot, then drop whatever it returns as an EntityItem -
     * like when you close a workbench GUI.
     */
    @Override
    public ItemStack removeStackFromSlot(int index)
    {
        return ItemStackHelper.getAndRemove(this.fryerItemStacks, index);
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void setInventorySlotContents(int index, ItemStack stack)
    {
        ItemStack itemstack = (ItemStack)this.fryerItemStacks.get(index);
        boolean flag = !stack.isEmpty() && stack.isItemEqual(itemstack) && ItemStack.areItemStackTagsEqual(stack, itemstack);
        this.fryerItemStacks.set(index, stack);

        if (stack.getCount() > this.getInventoryStackLimit())
        {
            stack.setCount(this.getInventoryStackLimit());
        }


    }

    /**
     * Returns the name of the inventory.
     */
    public String getInvName()
    {
        return this.isInvNameLocalized() ? this.displayName : "Fryer";
    }

    /**
     * If this returns false, the inventory name will be used as an unlocalized name, and translated into the player's
     * language. Otherwise it will be used directly.
     */
    public boolean isInvNameLocalized()
    {
        return this.displayName != null && this.displayName.length() > 0;
    }

    /**
     * Sets the custom display name to use when opening a GUI linked to this tile entity.
     */
    public void setGuiDisplayName(String string)
    {
        this.displayName = string;
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void readFromNBT(NBTTagCompound nbt)
    {
        super.readFromNBT(nbt);
 
        this.fryerItemStacks = NonNullList.<ItemStack>withSize(this.getSizeInventory(), ItemStack.EMPTY);
        ItemStackHelper.loadAllItems(nbt, this.fryerItemStacks);

        this.fryerBurnTime = nbt.getShort("BurnTime");
        this.fryerCookTime = nbt.getShort("CookTime");
        this.currentItemBurnTime = getItemBurnTime((ItemStack)this.fryerItemStacks.get(1));

        if (nbt.hasKey("Fryer"))
        {
            this.displayName = nbt.getString("Fryer");
        }
    }

    /**
     * Writes a tile entity to NBT.
     */
    public NBTTagCompound writeToNBT(NBTTagCompound nbt)
    {
        super.writeToNBT(nbt);
        nbt.setShort("BurnTime", (short)this.fryerBurnTime);
        nbt.setShort("CookTime", (short)this.fryerCookTime);
        ItemStackHelper.saveAllItems(nbt, this.fryerItemStacks);

        if (this.isInvNameLocalized())
        {
            nbt.setString("Fryer", this.displayName);
        }
        return nbt;
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended. *Isn't
     * this more of a set than a get?*
     */
    public int getInventoryStackLimit()
    {
        return 64;
    }

    @SideOnly(Side.CLIENT)

    /**
     * Returns an integer between 0 and the passed value representing how close the current item is to being completely
     * cooked
     */
    public int getCookProgressScaled(int par1)
    {
    	//change this to increase or decrease speed.  Lower number is faster
        return this.fryerCookTime * par1 / 100;
    }

    @SideOnly(Side.CLIENT)

    /**
     * Returns an integer between 0 and the passed value representing how much burn time is left on the current fuel
     * item, where 0 means that the item is exhausted and the passed value means that the item is fresh
     */
    public int getBurnTimeRemainingScaled(int par1)
    {
        if (this.currentItemBurnTime == 0)
        {
            this.currentItemBurnTime = 200;
        }

        return this.fryerBurnTime * par1 / this.currentItemBurnTime;
    }

    /**
     * Returns true if the furnace is currently burning
     */
    public boolean isBurning()
    {
        return this.fryerBurnTime > 0;
    }

    /**
     * Allows the entity to update its state. Overridden in most subclasses, e.g. the mob spawner uses this to count
     * ticks and creates a new spawn inside its implementation.
     */
    public void update()
    {
        boolean flag = this.fryerBurnTime > 0;
        boolean flag1 = false;

        if (this.fryerBurnTime > 0)
        {
            --this.fryerBurnTime;
        }

        if (!this.world.isRemote)
        {
        	ItemStack itemstack = (ItemStack)this.fryerItemStacks.get(1);
        	if (!this.isBurning() && this.canSmelt())
            {
                this.fryerBurnTime = getItemBurnTime(itemstack);
                this.currentItemBurnTime = this.fryerBurnTime;

                if (this.isBurning())
                {
                    flag1 = true;

                    if (!itemstack.isEmpty())
                    {
                        Item item = itemstack.getItem();
                        itemstack.shrink(1);

                        if (itemstack.isEmpty())
                        {
                            ItemStack item1 = item.getContainerItem(itemstack);
                            this.fryerItemStacks.set(1, item1);
                        }
                    }
                }
            }

            if (this.isBurning() && this.canSmelt())
            {
                ++this.fryerCookTime;
              //change this to increase or decrease speed.  Lower number is faster
                if (this.fryerCookTime == 100)
                {
                    this.fryerCookTime = 0;
                    this.smeltItem();
                    flag1 = true;
                }
            }
            else
            {
                this.fryerCookTime = 0;
            }

            if (flag != this.fryerBurnTime > 0)
            {
                flag1 = true;
                EBFryerClass.setState(this.fryerBurnTime > 0, this.world, new BlockPos(pos.getX(), pos.getY(), pos.getZ()));
            }
        }

        if (flag1)
        {
            this.markDirty();
        }
    }

    /**
     * Returns true if the furnace can smelt an item, i.e. has a source item, destination stack isn't full, etc.
     */
    private boolean canSmelt()
    {
        if (((ItemStack)this.fryerItemStacks.get(0)).isEmpty())
        {
            return false;
        }
        else
        {
            ItemStack itemstack = FryerRecipes.instance().getSmeltingResult((ItemStack)this.fryerItemStacks.get(0));

            if (itemstack.isEmpty())
            {
                return false;
            }
            else
            {
                ItemStack itemstack1 = (ItemStack)this.fryerItemStacks.get(2);
                if (itemstack1.isEmpty()) return true;
                if (!itemstack1.isItemEqual(itemstack)) return false;
                int result = itemstack1.getCount() + itemstack.getCount();
                return result <= getInventoryStackLimit() && result <= itemstack1.getMaxStackSize(); // Forge fix: make furnace respect stack sizes in furnace recipes
            }
        }
    }
 
    /**
     * Turn one item from the furnace source stack into the appropriate smelted item in the furnace result stack
     */
    
    public void smeltItem()
    {
        if (this.canSmelt())
        {
            ItemStack itemstack = (ItemStack)this.fryerItemStacks.get(0);
            ItemStack itemstack1 = FryerRecipes.instance().getSmeltingResult(itemstack);
            ItemStack itemstack2 = (ItemStack)this.fryerItemStacks.get(2);

            if (itemstack2.isEmpty())
            {
                this.fryerItemStacks.set(2, itemstack1.copy());
            }
            else if (itemstack2.getItem() == itemstack1.getItem())
            {
                itemstack2.grow(itemstack1.getCount());
            }

            if (itemstack.getItem() == Item.getItemFromBlock(Blocks.SPONGE) && itemstack.getMetadata() == 1 && !((ItemStack)this.fryerItemStacks.get(1)).isEmpty() && ((ItemStack)this.fryerItemStacks.get(1)).getItem() == Items.BUCKET)
            {
                this.fryerItemStacks.set(1, new ItemStack(Items.WATER_BUCKET));
            }

            itemstack.shrink(1);
        }
    }

    /**
     * Returns the number of ticks that the supplied fuel item will keep the furnace burning, or 0 if the item isn't
     * fuel
     */
    public static int getItemBurnTime(ItemStack itemStack)
    {
        if (itemStack.isEmpty())
        {
            return 0;
        }
        else
        {
            Item item = itemStack.getItem();
            if(item == EBVarInit.vegetableoil) return 1600;
            return net.minecraftforge.event.ForgeEventFactory.getItemBurnTime(itemStack);
        }
    }

    /**
     * Return true if item is a fuel source (getItemBurnTime() > 0).
     */
    public static boolean isItemFuel(ItemStack stack)
    {
        return getItemBurnTime(stack) > 0;
    }

    /**
     * Returns true if automation is allowed to insert the given stack (ignoring stack size) into the given slot.
     */
    public boolean isItemValidForSlot(int par1, ItemStack par2ItemStack)
    {
        return par1 == 2 ? false : (par1 == 1 ? isItemFuel(par2ItemStack) : true);
    }

    /**
     * Returns an array containing the indices of the slots that can be accessed by automation on the given side of this
     * block.
     */
    public int[] getAccessibleSlotsFromSide(int par1)
    {
        return par1 == 0 ? slots_bottom : (par1 == 1 ? slots_top : slots_sides);
    }

    /**
     * Returns true if automation can insert the given item in the given slot from the given side. Args: Slot, item,
     * side
     */
    public boolean canInsertItem(int par1, ItemStack par2ItemStack, int par3)
    {
        return this.isItemValidForSlot(par1, par2ItemStack);
    }

    /**
     * Returns true if automation can extract the given item in the given slot from the given side. Args: Slot, item,
     * side
     */
    public boolean canExtractItem(int par1, ItemStack par2ItemStack, int par3)
    {
        return par3 != 0 || par1 != 1 || par2ItemStack.getItem() == Items.BUCKET;
    }

	@Override
	public String getName() {
		
		return null;
	}

	@Override
	public boolean hasCustomName() {
	
		return false;
	}

	@Override
	public void openInventory(EntityPlayer player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closeInventory(EntityPlayer player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getField(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setField(int id, int value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getFieldCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void clear() {
		this.fryerItemStacks.clear();
	}

	@Override
	public ITextComponent getDisplayName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int[] getSlotsForFace(EnumFacing side) {
		return side == EnumFacing.DOWN ? slots_bottom : (side == EnumFacing.UP ? slots_top : slots_sides);
	}

	@Override
	public boolean canInsertItem(int slot, ItemStack itemstack, EnumFacing direction) {
		return this.isItemValidForSlot(slot, itemstack);
	}

	@Override
	public boolean canExtractItem(int slotId, ItemStack stack, EnumFacing direction) {
        if (direction == EnumFacing.DOWN && slotId == 1)
        {
            Item item = stack.getItem();

            if (item != Items.WATER_BUCKET && item != Items.BUCKET)
            {
                return false;
            }
        }

        return true;
	}

	@Override
	public boolean isEmpty() {
        for (ItemStack itemstack : this.fryerItemStacks)
        {
            if (!itemstack.isEmpty())
            {
                return false;
            }
        }

        return true;
	}

	@Override
	public boolean isUsableByPlayer(EntityPlayer player) {
        return this.world.getTileEntity(new BlockPos(pos)) != this ? false : player.getDistanceSq((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D) <= 64.0D;

	}

}
