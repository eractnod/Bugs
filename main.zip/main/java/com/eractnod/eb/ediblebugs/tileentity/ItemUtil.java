//This is taken from Crazypants and EnderIO Core.  Made is smaller to work with this mod

package com.eractnod.eb.ediblebugs.tileentity;

import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;

public class ItemUtil {

	  public static int doInsertItem(ISidedInventory inv, int startSlot, int endSlot, ItemStack item) {
		    return doInsertItemInv(inv, null, invSlotter.getInstance(startSlot, endSlot), item, null, true);
		  }
	
	 /* 
  		GetStackSize = ItemStack.func_190916_E getCount()
		SetStackSize = ItemStack.func_190920_e setCount()
		IncreaseStackSizeBy = ItemStack.func_190917_f grow()
		DecreaseStackSizeBy = ItemStack.func_190918_g  shrink()
		ItemStack.func_190926_b()  isEmpty()
		ItemStack.field_190927_a EMPTY
	*/
	  
	private static int doInsertItemInv(IInventory inv, ISidedInventory sidedInv, ISlotIterator slots, ItemStack item, EnumFacing inventorySide, boolean doInsert) {
	    int numInserted = 0;
	    int numToInsert = item.getCount();
	    int firstFreeSlot = -1;
	
	// PASS1: Try to add to an existing stack
	    
	while (numToInsert > 0 && slots.hasNext()) {
	  final int slot = slots.nextSlot();
	  if (sidedInv == null || sidedInv.canInsertItem(slot, item, inventorySide)) {
	    final ItemStack contents = inv.getStackInSlot(slot);
	    if (contents != null && contents.getItem() != Item.getItemFromBlock(Blocks.AIR)) {
	      if (areStackMergable(contents, item)) {
	        final int freeSpace = Math.min(inv.getInventoryStackLimit(), contents.getMaxStackSize()) - contents.getCount(); // some inventories like using itemstacks with invalid stack sizes
	        if (freeSpace > 0) {
			  final int noToInsert = Math.min(numToInsert, freeSpace);
			  final ItemStack toInsert = item.copy();

			  toInsert.setCount(contents.getCount() + noToInsert);
			  // isItemValidForSlot() may check the stacksize, so give it the number the stack would have in the end.
			  // If it does something funny, like "only even numbers", we are screwed.
	          if (sidedInv != null || inv.isItemValidForSlot(slot, toInsert)) {
	            numInserted += noToInsert;
	            numToInsert -= noToInsert;
	            if (doInsert) {
	              inv.setInventorySlotContents(slot, toInsert);
	            }
	          }
	        }
	      }
	    } else if (firstFreeSlot == -1) {
	      firstFreeSlot = slot;
	    }
	  }
	}
	
	// PASS2: Try to insert into an empty slot
	if (numToInsert > 0 && firstFreeSlot != -1) {
	  final ItemStack toInsert = item.copy();
	  toInsert.setCount(min(numToInsert, inv.getInventoryStackLimit(), toInsert.getMaxStackSize()));// some inventories like using itemstacks with invalid stack sizes

	      if (sidedInv != null || inv.isItemValidForSlot(firstFreeSlot, toInsert)) {
	        numInserted += toInsert.getCount();
	        numToInsert -= toInsert.getCount();
	        if (doInsert) {
	          inv.setInventorySlotContents(firstFreeSlot, toInsert);
	        }
	      }
	    }
	
	    if (numInserted > 0 && doInsert) {
	      inv.markDirty();
	    }
	    return numInserted;
	  }
	
	  private final static int min(int i1, int i2, int i3) {
	    return i1 < i2 ? (i1 < i3 ? i1 : i3) : (i2 < i3 ? i2 : i3);
	  }
	
	  /**
	   * Checks if items, damage and NBT are equal and the items are stackable.
	   * 
	   * @param s1
	   * @param s2
	   * @return True if the two stacks are mergeable, false otherwise.
	   */
	  public static boolean areStackMergable(ItemStack s1, ItemStack s2) {
	    if (s1 == null || s2 == null || !s1.isStackable() || !s2.isStackable()) {
	      return false;
	    }
	    if (!s1.isItemEqual(s2)) {
	      return false;
	    }
	    return ItemStack.areItemStackTagsEqual(s1, s2);
	  }
	
	  private interface ISlotIterator {
		  int nextSlot();
		  boolean hasNext();
	  }
	  
	  private final static class invSlotter implements ISlotIterator {
		    private static final invSlotter me = new invSlotter();
		    private int end;
		    private int current;
	
		    public final static invSlotter getInstance(int start, int end) {
		      me.end = end;
		      me.current = start;
		      return me;
		    }
	
		    @Override
		    public final int nextSlot() {
		      return current++;
		    }
	
		    @Override
		    public final boolean hasNext() {
		      return current < end;
		    }
		  }
	
	  private final static class sidedSlotter implements ISlotIterator {
		    private static final sidedSlotter me = new sidedSlotter();
		    private int[] slots;
		    private int current;
	
		    public final static sidedSlotter getInstance(int[] slots) {
		      me.slots = slots;
		      me.current = 0;
		      return me;
		    }
	
		    @Override
		    public final int nextSlot() {
		      return slots[current++];
		    }
	
		    @Override
		    public final boolean hasNext() {
		      return slots != null && current < slots.length;
		    }
		  }

}
