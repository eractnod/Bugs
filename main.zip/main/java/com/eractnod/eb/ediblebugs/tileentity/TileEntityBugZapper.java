package com.eractnod.eb.ediblebugs.tileentity;

import java.util.List;
import java.util.UUID;

import com.eractnod.eb.ediblebugs.blocks.TermiteBlockClass;
import com.eractnod.eb.ediblebugs.common.EBVarInit;
import com.eractnod.eb.ediblebugs.fakeplayer.EBFakePlayerFactory;
import com.mojang.authlib.GameProfile;

import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.util.FakePlayer;

public class TileEntityBugZapper extends TileEntity implements ITickable, ISidedInventory{

    private static final int[] SLOTS_TOP = new int[] {8,9,10,11,12,13,14,15,16};
    private static final int[] SLOTS_BOTTOM = new int[] {8,9,10,11,12,13,14,15,16};
    private static final int[] SLOTS_SIDES = new int[] {0,1,2,3,4,5,6,7};
    
    private NonNullList<ItemStack> zapperItemStacks = NonNullList.<ItemStack>withSize(17, ItemStack.EMPTY);

	//private ItemStack[] zapperItemStacks = new ItemStack[18];
	private String zapperName;

	private int timer = 100;
	
	@Override
	public int getSizeInventory() {
		return this.zapperItemStacks.size();
	}

	@Override
	public ItemStack getStackInSlot(int index) {
		return (ItemStack)this.zapperItemStacks.get(index);
	}

	@Override
    public ItemStack decrStackSize(int index, int count)
    {
        return ItemStackHelper.getAndSplit(this.zapperItemStacks, index, count);
    }

	@Override
	   public ItemStack removeStackFromSlot(int index)
    {
        return ItemStackHelper.getAndRemove(this.zapperItemStacks, index);
    }

	@Override
    public void setInventorySlotContents(int index, ItemStack stack)
    {
        ItemStack itemstack = (ItemStack)this.zapperItemStacks.get(index);
        boolean flag = !stack.isEmpty() && stack.isItemEqual(itemstack) && ItemStack.areItemStackTagsEqual(stack, itemstack);
        this.zapperItemStacks.set(index, stack);

        if (stack.getCount() > this.getInventoryStackLimit())
        {
            stack.setCount(this.getInventoryStackLimit());
        }

    }

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public boolean isUsableByPlayer(EntityPlayer player) {
	       return this.world.getTileEntity(new BlockPos(pos)) != this ? false : player.getDistanceSq((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D) <= 64.0D;
	}

	@Override
	public void openInventory(EntityPlayer player) {}

	@Override
	public void closeInventory(EntityPlayer player) {}

	@Override
	public int getField(int id) {
		return 0;
	}

	@Override
	public void setField(int id, int value) {
	}

	@Override
	public int getFieldCount() {
		return 0;
	}

	@Override
	public void clear() {
		this.zapperItemStacks.clear();
	}
	
	public void setGuiDisplayName(String string){
		this.zapperName = string;
	}
	
	@Override
	public String getName() {
		return this.hasCustomName() ? this.zapperName : "Termite Zapper";
	}

	@Override
	public boolean hasCustomName() {
		
		return this.zapperName != null && this.zapperName.length() > 0;
	}
	
	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack) {
		if(!world.isRemote){
			Item item = stack.getItem();
	    	Block block = Block.getBlockFromItem(item);
			if(index < 4){
				return block instanceof BlockDirt;
			}
			else if(index > 7 && index < 18){
				return true;
			}
			else if(index > 3 && index < 8){
				return stack.getItem() == EBVarInit.termiteLarva;
			}
			
			return false;
		}
		return true;
	
	}

	@Override
	public int[] getSlotsForFace(EnumFacing side) {
		
		 return side == EnumFacing.DOWN ? SLOTS_BOTTOM : (side == EnumFacing.UP ? SLOTS_TOP : SLOTS_SIDES);
	}

	@Override
	public boolean canInsertItem(int index, ItemStack itemStackIn, EnumFacing direction) {
		return this.isItemValidForSlot(index, itemStackIn);
	}

	@Override
	public boolean canExtractItem(int index, ItemStack stack, EnumFacing direction) {
        if (direction == EnumFacing.DOWN || direction == EnumFacing.UP && index > 7 && index < 17)
        {
        	return true;
        }

        return false;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		timer-=1;
		if(!world.isRemote){
			if(world.isBlockPowered(pos)){
				if(this.timer < 0){
					setDirtBlock();
					this.markDirty();
					this.timer = 100;
				}
				clickLarveOnDirtBlock();
				breakTermiteMound();
				doHoover();
			}
		}
	}

    private void doHoover() {
    	
    	AxisAlignedBB axis = new AxisAlignedBB(this.pos, this.pos).grow(9D);

		List<EntityItem> listItem = this.world.<EntityItem>getEntitiesWithinAABB(EntityItem.class, axis);

        for (EntityItem entity : listItem) {
          if (true) {
            double x = (pos.getX() + 0.5D - entity.posX);
            double y = (pos.getY() + 0.5D - entity.posY);
            double z = (pos.getZ() + 0.5D - entity.posZ);

            double distance = Math.sqrt(x * x + y * y + z * z);
            if (distance < 1.25) {
              hooverEntity(entity);
            } else {
              double speed = 0.06;
              double distScale = 1.0 - Math.min(0.9, distance / 36);
              distScale *= distScale;

              entity.motionX += x / distance * distScale * speed;
              entity.motionY += y / distance * distScale * 0.2;
              entity.motionZ += z / distance * distScale * speed;
            }
          }
        }
      }

      private void hooverEntity(Entity entity) {
        if (!world.isRemote) {
        	int numInserted = 0;
          if (entity instanceof EntityItem && !entity.isDead) {
            EntityItem item = (EntityItem) entity;
            ItemStack stack = item.getItem().copy();
            if(stack.getItem() == EBVarInit.termiteLarva){
            	numInserted = ItemUtil.doInsertItem(this, 4, 17, stack);
            }else{
            	numInserted = ItemUtil.doInsertItem(this, 8, 17, stack);
            }

            stack.shrink(numInserted);
            item.setItem(stack);

            if (stack.getCount() == 0) {
              item.setDead();
            }
          }
        }
      }

	private void breakTermiteMound() {
		Block blockNorth = world.getBlockState(pos.offset(EnumFacing.NORTH, 3).offset(EnumFacing.UP, 2)).getBlock();
		Block blockSouth = world.getBlockState(pos.offset(EnumFacing.SOUTH, 3).offset(EnumFacing.UP, 2)).getBlock();
		Block blockEast = world.getBlockState(pos.offset(EnumFacing.EAST, 3).offset(EnumFacing.UP, 2)).getBlock();
		Block blockWest = world.getBlockState(pos.offset(EnumFacing.WEST, 3).offset(EnumFacing.UP, 2)).getBlock();
		Block blockMound = EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE).getBlock();

		if(blockNorth.equals(blockMound)){
			breakMound(EnumFacing.NORTH, blockNorth);

		}
		if(blockSouth.equals(blockMound)){
			breakMound(EnumFacing.SOUTH, blockSouth);

		}
		if(blockEast.equals(blockMound)){
			breakMound(EnumFacing.EAST, blockEast);

		}
		if(blockWest.equals(blockMound)){
			breakMound(EnumFacing.WEST, blockWest);
		}
		
	}

	private void breakMound(EnumFacing face, Block block) {
		Block blockMound = EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE).getBlock();
		BlockPos blockPos = new BlockPos(this.pos.offset(face, 3));
		for(int y = 0; y < 3; y++){
			for(int x = -1; x < 2; x++){
				for(int z = -1; z < 2; z++){
					BlockPos newpos = new BlockPos(blockPos.getX() + x, blockPos.getY() + y, blockPos.getZ() + z);

					if (world.getBlockState(newpos).getBlock() == blockMound){
						world.getBlockState(newpos).getBlock().harvestBlock(world, EBFakePlayerFactory.getPlayer((WorldServer)world), newpos, block.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE), null, null);
						world.setBlockState(newpos, Blocks.AIR.getDefaultState(), 3);
					}
				}
			}
		}
		
	}

	private void clickLarveOnDirtBlock() {
       	for(int i = 4; i < 8; i++){
       			//May need to set back to null once the itemstack to air bug is fixed.
       			if(!this.zapperItemStacks.get(i).isEmpty() && world.getBlockState(pos.offset(EnumFacing.NORTH, 3)).getBlock() == Blocks.DIRT){
    			//if(this.zapperItemStacks.get(i).getItem() != Item.getItemFromBlock(Blocks.AIR) && worldObj.getBlockState(pos.offset(EnumFacing.NORTH, 3)).getBlock() == Blocks.DIRT){
    		    	world.setBlockState(pos.offset(EnumFacing.NORTH, 3), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.ACTIVE));
    		    	this.decrStackSize(i, 1);
    			}
    			if(!this.zapperItemStacks.get(i).isEmpty() && world.getBlockState(pos.offset(EnumFacing.SOUTH, 3)).getBlock() == Blocks.DIRT){
    				world.setBlockState(pos.offset(EnumFacing.SOUTH, 3), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.ACTIVE));
    				this.decrStackSize(i, 1);
    			}
    			if(!this.zapperItemStacks.get(i).isEmpty() && world.getBlockState(pos.offset(EnumFacing.EAST, 3)).getBlock() == Blocks.DIRT){
    				world.setBlockState(pos.offset(EnumFacing.EAST, 3), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.ACTIVE));
    				this.decrStackSize(i, 1);
    			}
    			if(!this.zapperItemStacks.get(i).isEmpty() && world.getBlockState(pos.offset(EnumFacing.WEST, 3)).getBlock() == Blocks.DIRT){
    				world.setBlockState(pos.offset(EnumFacing.WEST, 3), EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.ACTIVE));
    				this.decrStackSize(i, 1);
    			}
        	}
		
	}

	private void setDirtBlock() {
		boolean flag = true;
		if(!world.isRemote){
			Block blockNorth = world.getBlockState(pos.offset(EnumFacing.NORTH, 3)).getBlock();
			Block blockSouth = world.getBlockState(pos.offset(EnumFacing.SOUTH, 3)).getBlock();
			Block blockEast = world.getBlockState(pos.offset(EnumFacing.EAST, 3)).getBlock();
			Block blockWest = world.getBlockState(pos.offset(EnumFacing.WEST, 3)).getBlock();
			Block blockMound = EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.ACTIVE).getBlock();
			Block blockMoundI = EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE).getBlock();

			boolean larva = checkForLarva();
			for(int i = 0; i < 4; i++){
				if(!this.zapperItemStacks.get(i).isEmpty() && (blockNorth instanceof BlockAir) && larva == true){
				//if(this.zapperItemStacks.get(i).getItem() != Item.getItemFromBlock(Blocks.AIR) && (blockNorth instanceof BlockAir)){
					world.setBlockState(pos.offset(EnumFacing.NORTH, 3), Blocks.DIRT.getDefaultState());
					this.decrStackSize(i, 1);
					return;
				}
				if(!this.zapperItemStacks.get(i).isEmpty() && (blockSouth instanceof BlockAir) && larva == true){
				//if(this.zapperItemStacks.get(i).getItem() != Item.getItemFromBlock(Blocks.AIR) && (blockSouth instanceof BlockAir)){
					world.setBlockState(pos.offset(EnumFacing.SOUTH, 3), Blocks.DIRT.getDefaultState());
					this.decrStackSize(i, 1);
					return;
				}
				if(!this.zapperItemStacks.get(i).isEmpty() && (blockEast instanceof BlockAir) && larva == true){
				//if(this.zapperItemStacks.get(i).getItem() != Item.getItemFromBlock(Blocks.AIR) && (blockEast instanceof BlockAir)){
					world.setBlockState(pos.offset(EnumFacing.EAST, 3), Blocks.DIRT.getDefaultState());
					this.decrStackSize(i, 1);
					return;
				}
				if(!this.zapperItemStacks.get(i).isEmpty() && (blockWest instanceof BlockAir) && larva == true){
				//if(this.zapperItemStacks.get(i).getItem() != Item.getItemFromBlock(Blocks.AIR) && (blockWest instanceof BlockAir)){
					world.setBlockState(pos.offset(EnumFacing.WEST, 3), Blocks.DIRT.getDefaultState());
					this.decrStackSize(i, 1);
					return;
				}
	    	}
		}
	}

	private boolean checkForLarva() {
		for(int i = 4; i < 8; i++){
			if(!this.zapperItemStacks.get(i).isEmpty()) return true;
		}
		return false;
	}

	@Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt);
		ItemStackHelper.saveAllItems(nbt, this.zapperItemStacks);

		if(this.hasCustomName()){
			nbt.setString("CustomName", this.getName());
		}

		return nbt;
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
 
        this.zapperItemStacks = NonNullList.<ItemStack>withSize(this.getSizeInventory(), ItemStack.EMPTY);
        ItemStackHelper.loadAllItems(nbt, this.zapperItemStacks);

		if(nbt.hasKey("CustomeName")){
			this.zapperName = nbt.getString("CustomerName");
		}

		
    }

	@Override
	public ITextComponent getDisplayName() {
		return null;
	}
 
    net.minecraftforge.items.IItemHandler handlerTop = new net.minecraftforge.items.wrapper.SidedInvWrapper(this, net.minecraft.util.EnumFacing.UP);
    net.minecraftforge.items.IItemHandler handlerBottom = new net.minecraftforge.items.wrapper.SidedInvWrapper(this, net.minecraft.util.EnumFacing.DOWN);
    net.minecraftforge.items.IItemHandler handlerSide = new net.minecraftforge.items.wrapper.SidedInvWrapper(this, net.minecraft.util.EnumFacing.WEST);

    @SuppressWarnings("unchecked")
    @Override
    public <T> T getCapability(net.minecraftforge.common.capabilities.Capability<T> capability, net.minecraft.util.EnumFacing facing)
    {
        if (facing != null && capability == net.minecraftforge.items.CapabilityItemHandler.ITEM_HANDLER_CAPABILITY)
            if (facing == EnumFacing.DOWN)
                return (T) handlerBottom;
            else if (facing == EnumFacing.UP)
                return (T) handlerTop;
            else
                return (T) handlerSide;
        return super.getCapability(capability, facing);
    }

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}
    
}
