package com.eractnod.eb.ediblebugs.proxy;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.block.model.ModelBakery;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class ClientProxy extends CommonProxy{
	
	public static void preInit() 
	{
		bugsModelBakery(EBVarInit.grassBugs, new String[]{EdibleBugs.MODID + ":grasshopper", EdibleBugs.MODID + ":locust", EdibleBugs.MODID + ":cricket", EdibleBugs.MODID + ":aphid"});
		bugsModelBakery(EBVarInit.dirtBugs, new String[]{EdibleBugs.MODID + ":fireant", EdibleBugs.MODID + ":slug", EdibleBugs.MODID + ":sowbug", EdibleBugs.MODID + ":dungbeetle"});
		bugsModelBakery(EBVarInit.woodBugs, new String[]{EdibleBugs.MODID + ":carpenterant", EdibleBugs.MODID + ":woodtermite", EdibleBugs.MODID + ":jumil", EdibleBugs.MODID + ":witchettygrub"});
		bugsModelBakery(EBVarInit.sandBugs, new String[]{EdibleBugs.MODID + ":camelspider", EdibleBugs.MODID + ":scorpion", EdibleBugs.MODID + ":centipede", EdibleBugs.MODID + ":scarab"});
		
		bugsModelBakery(EBVarInit.cookedBugs, new String[]{EdibleBugs.MODID + ":cgrasshopper", EdibleBugs.MODID + ":clocust", EdibleBugs.MODID + ":ccricket", EdibleBugs.MODID + ":caphid", EdibleBugs.MODID + ":cfireant", EdibleBugs.MODID + ":cslug", EdibleBugs.MODID + ":csowbug", EdibleBugs.MODID + ":cdungbeetle", EdibleBugs.MODID + ":ccarpenterant", EdibleBugs.MODID + ":cwoodtermite", EdibleBugs.MODID + ":cjumil", EdibleBugs.MODID + ":cwitchettygrub", EdibleBugs.MODID + ":ctermite", EdibleBugs.MODID + ":ccamelspider", EdibleBugs.MODID + ":cscorpion", EdibleBugs.MODID + ":ccentipede", EdibleBugs.MODID + ":cscarab"});
		bugsModelBakery(Item.getItemFromBlock(EBVarInit.termiteBlock), new String[]{EdibleBugs.MODID + ":termiteblock", EdibleBugs.MODID + ":active_termiteblock"});
	}

	public static void init(){

		
		for(String name : EBVarInit.blockList){
			//Item i = GameRegistry.findItem(EdibleBugs.MODID, name);
			Item i = Item.REGISTRY.getObject(new ResourceLocation("ediblebugs:" + name));
			registerItem(i, EdibleBugs.MODID + ":" + name);
		}
		registerBlock(EBVarInit.EBfryerIdle, 0, EdibleBugs.MODID + ":ebfryeridle");
		registerBlock(EBVarInit.EBfryerActive, 1, EdibleBugs.MODID + ":ebfryeractive");

		registerBlock(EBVarInit.termiteBlock, 0, EdibleBugs.MODID + ":termiteblock");
		registerBlock(EBVarInit.termiteBlock, 1, EdibleBugs.MODID + ":active_termiteblock");
		
		registerBlock(EBVarInit.termiteBricks, EdibleBugs.MODID + ":termitebricks");
		
		registerItem(EBVarInit.grassBugs, 3, EdibleBugs.MODID + ":grasshopper");
		registerItem(EBVarInit.grassBugs, 2, EdibleBugs.MODID + ":locust");
		registerItem(EBVarInit.grassBugs, 1, EdibleBugs.MODID + ":cricket");
		registerItem(EBVarInit.grassBugs, 0, EdibleBugs.MODID + ":aphid");
		
		registerItem(EBVarInit.dirtBugs, 3, EdibleBugs.MODID + ":fireant");
		registerItem(EBVarInit.dirtBugs, 2, EdibleBugs.MODID + ":slug");
		registerItem(EBVarInit.dirtBugs, 1, EdibleBugs.MODID + ":sowbug");
		registerItem(EBVarInit.dirtBugs, 0, EdibleBugs.MODID + ":dungbeetle");
		
		registerItem(EBVarInit.woodBugs, 3, EdibleBugs.MODID + ":carpenterant");
		registerItem(EBVarInit.woodBugs, 2, EdibleBugs.MODID + ":woodtermite");
		registerItem(EBVarInit.woodBugs, 1, EdibleBugs.MODID + ":jumil");
		registerItem(EBVarInit.woodBugs, 0, EdibleBugs.MODID + ":witchettygrub");
		
		registerItem(EBVarInit.sandBugs, 3, EdibleBugs.MODID + ":camelspider");
		registerItem(EBVarInit.sandBugs, 2, EdibleBugs.MODID + ":scorpion");
		registerItem(EBVarInit.sandBugs, 1, EdibleBugs.MODID + ":centipede");
		registerItem(EBVarInit.sandBugs, 0, EdibleBugs.MODID + ":scarab");
		
		registerItem(EBVarInit.cookedBugs, 16, EdibleBugs.MODID + ":cgrasshopper");
		registerItem(EBVarInit.cookedBugs, 15, EdibleBugs.MODID + ":clocust");
		registerItem(EBVarInit.cookedBugs, 14, EdibleBugs.MODID + ":ccricket");
		registerItem(EBVarInit.cookedBugs, 13, EdibleBugs.MODID + ":caphid");
		registerItem(EBVarInit.cookedBugs, 12, EdibleBugs.MODID + ":cfireant");
		registerItem(EBVarInit.cookedBugs, 11, EdibleBugs.MODID + ":cslug");
		registerItem(EBVarInit.cookedBugs, 10, EdibleBugs.MODID + ":csowbug");
		registerItem(EBVarInit.cookedBugs, 9, EdibleBugs.MODID + ":cdungbeetle");
		registerItem(EBVarInit.cookedBugs, 8, EdibleBugs.MODID + ":ccarpenterant");
		registerItem(EBVarInit.cookedBugs, 7, EdibleBugs.MODID + ":cwoodtermite");
		registerItem(EBVarInit.cookedBugs, 6, EdibleBugs.MODID + ":cjumil");
		registerItem(EBVarInit.cookedBugs, 5, EdibleBugs.MODID + ":cwitchettygrub");
		registerItem(EBVarInit.cookedBugs, 4, EdibleBugs.MODID + ":ctermite");
		registerItem(EBVarInit.cookedBugs, 3, EdibleBugs.MODID + ":ccamelspider");
		registerItem(EBVarInit.cookedBugs, 2, EdibleBugs.MODID + ":cscorpion");
		registerItem(EBVarInit.cookedBugs, 1, EdibleBugs.MODID + ":ccentipede");
		registerItem(EBVarInit.cookedBugs, 0, EdibleBugs.MODID + ":cscarab");

		registerItem(EBVarInit.termiteLarva, EdibleBugs.MODID + ":termitelarva");
		registerItem(EBVarInit.termite, EdibleBugs.MODID + ":termite");
		registerItem(EBVarInit.vegetableoil, EdibleBugs.MODID + ":vegetableoil");
		registerItem(EBVarInit.termiteClay, EdibleBugs.MODID + ":termiteclay");
		registerItem(EBVarInit.termiteBrick, EdibleBugs.MODID + ":termitebrick");

		registerBlock(EBVarInit.bugZapper, EdibleBugs.MODID + ":bugzapper");
		registerBlock(EBVarInit.ebTermiteStair, EdibleBugs.MODID + ":ebtermitestair");
		
		registerBlock(EBVarInit.ebSlabS, 0, EdibleBugs.MODID + ":ebslabs");
	}

	public static void bugsModelBakery(Item item, String[] string){
		for (int i = 0; i < string.length; i++){
			ModelBakery.registerItemVariants(item, new ResourceLocation(string[i]));
		}
	}
	
	public static void registerItem(Item item, int metadata, String itemName)
    {
        ItemModelMesher mesher = Minecraft.getMinecraft().getRenderItem().getItemModelMesher();
        mesher.register(item, metadata, new ModelResourceLocation(itemName, "inventory"));
    }

    public static void registerBlock(Block block, int metadata, String blockName)
    {
        registerItem(Item.getItemFromBlock(block), metadata, blockName);
    }

    public static void registerBlock(Block block, String blockName)
    {
        registerBlock(block, 0, blockName);
    }

    public static void registerItem(Item item, String itemName)
    {
        registerItem(item, 0, itemName);
    }

}
