package com.eractnod.eb.ediblebugs.proxy;

public class CommonProxy {
	public static void renderStuff() 
	{
		
	}

	public void registerRenderers() {
		
	}



}
