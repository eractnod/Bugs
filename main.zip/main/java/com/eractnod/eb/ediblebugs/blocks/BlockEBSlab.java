package com.eractnod.eb.ediblebugs.blocks;

import java.util.Random;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

import net.minecraft.block.BlockSlab;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockEBSlab extends BlockSlab
{
    public static final PropertyBool seamlessBoolEBSlab = PropertyBool.create("seamless");
    public static final PropertyEnum<EnumType> typeVarEBSlab = PropertyEnum.create("variant", BlockEBSlab.EnumType.class);

    public BlockEBSlab(Material mat, String name, float hardness, float resistance)
    {
        super(Material.ROCK);
        IBlockState iblockstate = this.blockState.getBaseState();
        if (this.isDouble())
        {
            iblockstate = iblockstate.withProperty(seamlessBoolEBSlab, Boolean.valueOf(false));
        }
        else
        {
            iblockstate = iblockstate.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
        }
        this.setDefaultState(iblockstate.withProperty(typeVarEBSlab, BlockEBSlab.EnumType.TERMITE));
        this.setCreativeTab(EdibleBugs.tabEdibleBugs);
        this.setHardness(hardness);
        this.setResistance(resistance);
        this.useNeighborBrightness = true;
        this.setHarvestLevel("pickaxe", 1);
    }

    public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
        return Item.getItemFromBlock(EBVarInit.ebSlabS);
    }

    @SideOnly(Side.CLIENT)
    public Item getItem(World worldIn, BlockPos pos)
    {
    	
        return Item.getItemFromBlock(EBVarInit.ebSlabS);
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void getSubBlocks(CreativeTabs tab, NonNullList<ItemStack> list)
    {
        //if (itemIn != Item.getItemFromBlock(DPVarInit.dpSlabD))
        //{
            BlockEBSlab.EnumType[] aenumtype = BlockEBSlab.EnumType.values();
            int i = aenumtype.length;

            for (int j = 0; j < i; ++j)
            {
                BlockEBSlab.EnumType enumtype = aenumtype[j];

                    list.add(new ItemStack(this, 1, enumtype.getMetaFromState()));
               
            }
        //}
    }

    public IBlockState getStateFromMeta(int meta)
    {
        IBlockState iblockstate = this.getDefaultState().withProperty(typeVarEBSlab, BlockEBSlab.EnumType.func_176625_a(meta & 7));

        if (this.isDouble())
        {
            iblockstate = iblockstate.withProperty(seamlessBoolEBSlab, Boolean.valueOf((meta & 8) != 0));
        }
        else
        {
            iblockstate = iblockstate.withProperty(HALF, (meta & 8) == 0 ? BlockSlab.EnumBlockHalf.BOTTOM : BlockSlab.EnumBlockHalf.TOP);
        }

        return iblockstate;
    }

    public int getMetaFromState(IBlockState state)
    {
        byte b0 = 0;
        int i = b0 | ((BlockEBSlab.EnumType)state.getValue(typeVarEBSlab)).getMetaFromState();

        if (this.isDouble())
        {
            if (((Boolean)state.getValue(seamlessBoolEBSlab)).booleanValue())
            {
                i |= 8;
            }
        }
        else if (state.getValue(HALF) == BlockSlab.EnumBlockHalf.TOP)
        {
            i |= 8;
        }

        return i;
    }

    protected BlockStateContainer createBlockState()
    {
        return this.isDouble() ? new BlockStateContainer(this, new IProperty[] {seamlessBoolEBSlab, typeVarEBSlab}): new BlockStateContainer(this, new IProperty[] {HALF, typeVarEBSlab});
    }

    public int damageDropped(IBlockState state)
    {
        return ((BlockEBSlab.EnumType)state.getValue(typeVarEBSlab)).getMetaFromState();
    }

    public static enum EnumType implements IStringSerializable
    {
    	TERMITE(0, "ebslabs", "ebslabs");;
    	
        private static final BlockEBSlab.EnumType[] field_176640_i = new BlockEBSlab.EnumType[values().length];
        private final int meta;
        private final String variantName;
        private final String name;


        private EnumType(int meta, String name)
        {
            this(meta, name, name);
        }

        private EnumType(int meta, String variantName, String name)
        {
            this.meta = meta;
            this.variantName = variantName;
            this.name = name;
        }

        public int getMetaFromState()
        {
            return this.meta;
        }

        public String toString()
        {
            return this.variantName;
        }

        public static BlockEBSlab.EnumType func_176625_a(int meta)
        {
            if (meta < 0 || meta >= field_176640_i.length)
            {
                meta = 0;
            }

            return field_176640_i[meta];
        }

        public String getName()
        {
            return this.variantName;
        }

        public String func_176627_c()
        {
            return this.name;
        }

        static
        {
            BlockEBSlab.EnumType[] var0 = values();
            int var1 = var0.length;

            for (int var2 = 0; var2 < var1; ++var2)
            {
                BlockEBSlab.EnumType var3 = var0[var2];
                field_176640_i[var3.getMetaFromState()] = var3;
            }
        }
    }

	@Override
	public boolean isDouble() {
		return false;
	}

	@Override
	public String getUnlocalizedName(int meta) {
		return super.getUnlocalizedName() + "." + BlockEBSlab.EnumType.func_176625_a(meta).func_176627_c();
	}

	@Override
	public IProperty<EnumType> getVariantProperty() {
		return typeVarEBSlab;
	}

	@Override
	public Comparable<?> getTypeForItem(ItemStack stack) {
		return BlockEBSlab.EnumType.func_176625_a(stack.getMetadata() & 7);
	}

}