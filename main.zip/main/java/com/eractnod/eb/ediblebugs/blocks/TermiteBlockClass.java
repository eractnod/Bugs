package com.eractnod.eb.ediblebugs.blocks;

import java.util.List;
import java.util.Random;

import javax.annotation.Nullable;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStone;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class TermiteBlockClass extends Block{

	public static final PropertyEnum VARIANT_PROP = PropertyEnum.create("variant", TermiteBlockClass.EnumType.class);
    public static final int INACTIVE_META = TermiteBlockClass.EnumType.INACTIVE.getMetaFromState();
    public static final int ACTIVE_META = TermiteBlockClass.EnumType.ACTIVE.getMetaFromState();
    
	public TermiteBlockClass(Material material, String name, float hardness, float resistance) {
		super(material);
		
		setCreativeTab(EdibleBugs.tabEdibleBugs);
	    setHardness(hardness);
	    this.setResistance(resistance);
	    setSoundType(SoundType.GROUND);
	    setTickRandomly(true);
	    this.setDefaultState(this.blockState.getBaseState().withProperty(VARIANT_PROP, TermiteBlockClass.EnumType.INACTIVE));
	
	}

	 @Override
    @SideOnly(Side.CLIENT)
	public void getSubBlocks(CreativeTabs tab, NonNullList<ItemStack> list)
    {
		 TermiteBlockClass.EnumType[] aenumtype = TermiteBlockClass.EnumType.values();
        int i = aenumtype.length;

        for (int j = 0; j < i; ++j)
        {
        	TermiteBlockClass.EnumType enumtype = aenumtype[j];
            list.add(new ItemStack(this, 1, enumtype.getMetaFromState()));
        }
    }

	@Override
	public void harvestBlock(World worldIn, EntityPlayer player, BlockPos pos, IBlockState state, @Nullable TileEntity te, @Nullable ItemStack stack)
	{
	        harvesters.set(null);
	        //int i = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, stack);
	        int i = 0;
	        this.dropBlockAsItem(worldIn, pos, state, i);
	        harvesters.set(null);
	
	}
	    
    public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
    	return EBVarInit.termite;
    }

    public int damageDropped(IBlockState state)
    {
    	return 0;
    }

   
   /**
    * Returns the quantity of items to drop on block destruction.
    */
   public int quantityDropped(Random rand)
   {
       return 1 + rand.nextInt(3);
   }

   /**
    * This returns a complete list of items dropped from this block.
    *
    * @param world The current world
    * @param pos Block position in world
    * @param state Current state
    * @param fortune Breakers fortune level
    * @return A ArrayList containing all items this block drops
    */
   @Override
   public List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune)
   {
       List<ItemStack> ret = super.getDrops(world, pos, state, fortune);
       Random rand = world instanceof World ? ((World)world).rand : RANDOM;
       ret.add(new ItemStack(EBVarInit.termiteClay, 4, 0));
       if (rand.nextInt(EBVarInit.chanceLarva) == 0)
       {
    	   ret.add(new ItemStack(EBVarInit.termiteLarva, 2, 0));
       }

       return ret;
   }
    
   @Override
   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand){
	   
	   if (world.getBlockState(pos) == this.getStateFromMeta(ACTIVE_META) && rand.nextInt(EBVarInit.moundGrowth) == 0){

		   if (world.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ() - 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ() - 1), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ() + 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ() + 1), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ())) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ()), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ())) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ()), this.getStateFromMeta(INACTIVE_META));
	   	   }else if (world.getBlockState(new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ() - 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ() - 1), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ() + 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() - 1, pos.getY(), pos.getZ() + 1), this.getStateFromMeta(INACTIVE_META));
	   	   }else if (world.getBlockState(new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ() + 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ() + 1), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ() - 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() + 1, pos.getY(), pos.getZ() - 1), this.getStateFromMeta(INACTIVE_META));
	   	   }else if (world.getBlockState(new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ())) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ()), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX() + 1, pos.getY() + 1, pos.getZ())) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() + 1, pos.getY() + 1, pos.getZ()), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX() - 1, pos.getY() + 1, pos.getZ())) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX() - 1, pos.getY() + 1, pos.getZ()), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ() + 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ() + 1), this.getStateFromMeta(INACTIVE_META));;
		   }else if (world.getBlockState(new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ() - 1)) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX(), pos.getY() + 1, pos.getZ() - 1), this.getStateFromMeta(INACTIVE_META));
		   }else if (world.getBlockState(new BlockPos(pos.getX(), pos.getY() + 2, pos.getZ())) != this.getStateFromMeta(INACTIVE_META)){
			   world.setBlockState(new BlockPos(pos.getX(), pos.getY() + 2, pos.getZ()), this.getStateFromMeta(INACTIVE_META));
	   		   world.setBlockState(pos, this.getStateFromMeta(INACTIVE_META));
		   }
	   }
   }
    
   @Override
   public IBlockState getStateFromMeta(int meta)
   {
       return this.getDefaultState().withProperty(VARIANT_PROP, TermiteBlockClass.EnumType.getStateFromMeta(meta));
   }

   @Override
   public int getMetaFromState(IBlockState state)
   {
       return ((TermiteBlockClass.EnumType)state.getValue(VARIANT_PROP)).getMetaFromState();
   }
   
   @Override
   protected BlockStateContainer createBlockState()
   {
       return new BlockStateContainer(this, new IProperty[] {VARIANT_PROP});
   }
   
   public static enum EnumType implements IStringSerializable
   {
       INACTIVE(0, "termiteblock", "inactive"),
       ACTIVE(1, "active_termiteblock", "active");
       
       private static final TermiteBlockClass.EnumType[] TYPES_ARRAY = new TermiteBlockClass.EnumType[values().length];
       private final int meta;
       private final String textureName;
       private final String variantName;

       private EnumType(int p_i45679_3_, String p_i45679_4_, String p_i45679_5_)
       {
           this.meta = p_i45679_3_;
           this.textureName = p_i45679_4_;
           this.variantName = p_i45679_5_;
       }

       public int getMetaFromState()
       {
           return this.meta;
       }

       public String toString()
       {
           return this.textureName;
       }

       public static TermiteBlockClass.EnumType getStateFromMeta(int p_176613_0_)
       {
           if (p_176613_0_ < 0 || p_176613_0_ >= TYPES_ARRAY.length)
           {
               p_176613_0_ = 0;
           }

           return TYPES_ARRAY[p_176613_0_];
       }

       public String getName()
       {
           return this.textureName;
       }

       public String getVariantName()
       {
           return this.variantName;
       }

       static
       {
    	   TermiteBlockClass.EnumType[] var0 = values();
           int var1 = var0.length;

           for (int var2 = 0; var2 < var1; ++var2)
           {
        	   TermiteBlockClass.EnumType var3 = var0[var2];
               TYPES_ARRAY[var3.getMetaFromState()] = var3;
           }
       }
   }
   
}
