package com.eractnod.eb.ediblebugs.blocks;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityBugZapper;

import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockBugZapperClass extends BlockContainer {

	private static boolean keepInventory;
	public BlockBugZapperClass(Material materialIn) {
		super(materialIn);
		this.setCreativeTab(EdibleBugs.tabEdibleBugs);
		this.setHardness(0.5F);
		this.setResistance(10.0F);
		
	}

	@Override
	public boolean onBlockActivated(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumHand hand, EnumFacing heldItem, float side, float hitX, float hitY)
	{
		if (!world.isRemote){
	        TileEntity tile = world.getTileEntity(pos);
	        if (tile != null && tile instanceof TileEntityBugZapper) {
        		player.openGui(EdibleBugs.instance, EBVarInit.guiIDBugZapper, world, pos.getX(), pos.getY(), pos.getZ());
        		return true;
	        }
	    }

		return true;
	}

    @Override
    public TileEntity createNewTileEntity(World world, int meta) {
        return new TileEntityBugZapper();
    }
    
    /**
     * Called on server worlds only when the block has been replaced by a different block ID, or the same block with a
     * different metadata value, but before the new metadata value is set. Args: World, x, y, z, old block ID, old
     * metadata
     */
    @Override
    public void breakBlock(World world, BlockPos pos, IBlockState state)
    {
        if (!keepInventory)
        {
        	TileEntityBugZapper tileentity = (TileEntityBugZapper)world.getTileEntity(pos);
        	 if (tileentity instanceof TileEntityBugZapper)
             {
                 InventoryHelper.dropInventoryItems(world, pos, (TileEntityBugZapper)tileentity);
                 world.updateComparatorOutputLevel(pos, this);
             }
         }

         super.breakBlock(world, pos, state);

    }

    @Override
    public boolean hasComparatorInputOverride(IBlockState state)
    {
        return true;
    }

    @Override
    public int getComparatorInputOverride(IBlockState blockState, World worldIn, BlockPos pos)
    {
        return Container.calcRedstone(worldIn.getTileEntity(pos));
    }

    @SideOnly(Side.CLIENT)
    @Override
    public ItemStack getItem(World worldIn, BlockPos pos, IBlockState state)
    {
        return new ItemStack(EBVarInit.bugZapper);
    }


    /**
     * The type of render function called. 3 for standard block models, 2 for TESR's, 1 for liquids, -1 is no render
     */
    @Override
    public EnumBlockRenderType getRenderType(IBlockState state)
    {
        return EnumBlockRenderType.MODEL;
    }

}
