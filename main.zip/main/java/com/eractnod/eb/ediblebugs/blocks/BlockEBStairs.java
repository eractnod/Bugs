package com.eractnod.eb.ediblebugs.blocks;

import com.eractnod.eb.ediblebugs.EdibleBugs;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.SoundType;
import net.minecraft.block.BlockStairs.EnumHalf;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockEBStairs extends BlockStairs{

	private boolean ignoreSimilarity = false;
	
	public BlockEBStairs(Block b, IBlockState modelBlockState, float hard, float resist, SoundType soundStep) {
		super(modelBlockState);
		this.setCreativeTab(EdibleBugs.tabEdibleBugs);
		this.useNeighborBrightness = true;
		this.setHardness(hard);
		this.setResistance(resist);
		this.setSoundType(soundStep);
	}

    
}

