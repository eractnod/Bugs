package com.eractnod.eb.ediblebugs.blocks;

import net.minecraft.block.material.Material;

public class BlockEBSlabDouble extends BlockEBSlab{

	public BlockEBSlabDouble(Material mat, String name, float hardness, float resistance) {
		super(mat, name, hardness, resistance);
		setCreativeTab(null);
	}

	@Override
	public boolean isDouble(){
		return true;
	}
	

}

