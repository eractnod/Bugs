package com.eractnod.eb.ediblebugs.blocks;

import com.eractnod.eb.ediblebugs.EdibleBugs;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class TermiteBricksClass extends Block {

	public TermiteBricksClass(Material material, float hardness, float resistance) {
		super(material);
		
		setCreativeTab(EdibleBugs.tabEdibleBugs);
	    setHardness(hardness);
	    this.setResistance(resistance);
	    setSoundType(SoundType.STONE);
	
	}
	
}
