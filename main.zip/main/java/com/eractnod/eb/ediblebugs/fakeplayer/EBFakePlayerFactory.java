package com.eractnod.eb.ediblebugs.fakeplayer;

import java.util.UUID;
import net.minecraft.world.WorldServer;
import com.mojang.authlib.GameProfile;

public class EBFakePlayerFactory {
	
	private static GameProfile profile = new GameProfile(UUID.randomUUID(), "[EBFakePlayer]");
	private static EBFakePlayer EB_PLAYER = null;

	public static EBFakePlayer getPlayer(WorldServer world)
	{
		if (EB_PLAYER == null)
		{
			EB_PLAYER = new EBFakePlayer(world, profile);
		}
		return EB_PLAYER;
	}
}

