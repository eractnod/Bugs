package com.eractnod.eb.ediblebugs.fakeplayer;

import com.mojang.authlib.GameProfile;

import net.minecraft.world.WorldServer;
import net.minecraftforge.common.util.FakePlayer;

public class EBFakePlayer extends FakePlayer{

	public EBFakePlayer(WorldServer world, GameProfile name) {
		super(world, name);
		// TODO Auto-generated constructor stub
	}

}
