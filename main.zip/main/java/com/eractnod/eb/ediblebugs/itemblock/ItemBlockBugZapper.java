package com.eractnod.eb.ediblebugs.itemblock;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.block.Block;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemBlockBugZapper extends ItemBlock {

	public final Block block;
	public ItemBlockBugZapper(Block block) {
		super(block);
		this.block = block;
	}

    /**
     * allows items to add custom lines of information to the mouseover description
     */
    @SideOnly(Side.CLIENT)
    @Override
    public void addInformation(ItemStack stack, @Nullable World playerIn, List<String> tooltip, ITooltipFlag advanced)
    {
    	tooltip.add("Use this block for termite mound automation.");
    	tooltip.add("Add dirt and termite larve to the bug zapper");
    	tooltip.add("and apply a redstone signal");
    	tooltip.add("This will set the dirt block and right click it with the larve");
    	tooltip.add("Once the mound has finished growing, it will harvest the mound");
    	tooltip.add("Insert dirt and larve from the sides.");
    	tooltip.add("Extract termites etc from the top or bottom.");
        block.addInformation(stack, playerIn, tooltip, advanced);
    }

    
}
