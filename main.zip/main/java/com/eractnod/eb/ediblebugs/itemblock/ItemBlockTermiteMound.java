package com.eractnod.eb.ediblebugs.itemblock;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.block.Block;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemBlockTermiteMound extends ItemBlock {
	
	public ItemBlockTermiteMound(Block block) {
		super(block);
		setHasSubtypes(true);
	}

	@Override
	public String getUnlocalizedName(ItemStack itemstack) {
		String name = "";
		switch (itemstack.getItemDamage()) {
		case 0: {
			name = "";
			break;
		}
		case 1: {
			name = "active";
			break;
		}

		}
		return getUnlocalizedName() + name;
	}

	@Override
	public int getMetadata(int par1) {
		return par1;
	}
	
    /**
     * allows items to add custom lines of information to the mouseover description
     */
	@Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World playerIn, List<String> tooltip, ITooltipFlag advanced)
    {
    	tooltip.add("This mound will grow into a new bigger termite mound.");
        block.addInformation(stack, playerIn, tooltip, advanced);
		//if (stack.getItem() == DPVarInit.dpTurbine_Netherstar) this.display = "RF/t = " + DPVarInit.netherstarTurbine;
		//list.add(TextFormatting.LIGHT_PURPLE + display);
    }
}
