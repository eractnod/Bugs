package com.eractnod.eb.ediblebugs.items;

import net.minecraft.util.IStringSerializable;

public enum EnumSandBugs implements IStringSerializable
{
    CAMELSPIDER(0, 3, "camelspider", "camelspider"),
    SCORPION(1, 2, "scorpion", "scorpion"),
    CENTIPEDE(2, 1, "centipede", "centipede"),
    SCARAB(3, 0, "scarab", "scarab");
    
    public static final int CAMELSPIDER_META = EnumSandBugs.CAMELSPIDER.getIngotDamage();
    public static final int SCORPION_META = EnumSandBugs.SCORPION.getIngotDamage();
    public static final int CENTIPEDE_META = EnumSandBugs.CENTIPEDE.getIngotDamage();
    public static final int SCARAB_META = EnumSandBugs.SCARAB.getIngotDamage();

    
    private static final EnumSandBugs[] field_176790_q = new EnumSandBugs[values().length];
    private static final EnumSandBugs[] field_176789_r = new EnumSandBugs[values().length];
    private final int meta;
    private final int damage;
    private final String name;
    private final String string;

    private EnumSandBugs(int meta, int damage, String name, String string)
    {
        this.meta = meta;
        this.damage = damage;
        this.name = name;
        this.string = string;
    }

    public int func_176765_a()
    {
        return this.meta;
    }

    public int getIngotDamage()
    {
        return this.damage;
    }

    public String func_176762_d()
    {
        return this.string;
    }

   
    public static EnumSandBugs func_176766_a(int p_176766_0_)
    {
        if (p_176766_0_ < 0 || p_176766_0_ >= field_176789_r.length)
        {
            p_176766_0_ = 0;
        }

        return field_176789_r[p_176766_0_];
    }

    public static EnumSandBugs func_176764_b(int p_176764_0_)
    {
        if (p_176764_0_ < 0 || p_176764_0_ >= field_176790_q.length)
        {
            p_176764_0_ = 0;
        }

        return field_176790_q[p_176764_0_];
    }

    public String toString()
    {
        return this.string;
    }

    public String getName()
    {
        return this.name;
    }

    static
    {
        EnumSandBugs[] var0 = values();
        int var1 = var0.length;

        for (int var2 = 0; var2 < var1; ++var2)
        {
            EnumSandBugs var3 = var0[var2];
            field_176790_q[var3.func_176765_a()] = var3;
            field_176789_r[var3.getIngotDamage()] = var3;
        }
    }
}