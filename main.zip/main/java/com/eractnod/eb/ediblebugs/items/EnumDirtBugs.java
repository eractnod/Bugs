package com.eractnod.eb.ediblebugs.items;

import net.minecraft.util.IStringSerializable;

public enum EnumDirtBugs implements IStringSerializable
{
    FIREANT(0, 3, "fireant", "fireant"),
    SLUG(1, 2, "slug", "slug"),
    SOWBUG(2, 1, "sowbug", "sowbug"),
    DUNGBEETLE(3, 0, "dungbeetle", "dungbeetle");
    
    public static final int FIREANT_META = EnumDirtBugs.FIREANT.getIngotDamage();
    public static final int SLUG_META = EnumDirtBugs.SLUG.getIngotDamage();
    public static final int SOWBUG_META = EnumDirtBugs.SOWBUG.getIngotDamage();
    public static final int DUNGBEETLE_META = EnumDirtBugs.DUNGBEETLE.getIngotDamage();

    
    private static final EnumDirtBugs[] field_176790_q = new EnumDirtBugs[values().length];
    private static final EnumDirtBugs[] field_176789_r = new EnumDirtBugs[values().length];
    private final int meta;
    private final int damage;
    private final String name;
    private final String string;

    private EnumDirtBugs(int meta, int damage, String name, String string)
    {
        this.meta = meta;
        this.damage = damage;
        this.name = name;
        this.string = string;
    }

    public int func_176765_a()
    {
        return this.meta;
    }

    public int getIngotDamage()
    {
        return this.damage;
    }

    public String func_176762_d()
    {
        return this.string;
    }

   
    public static EnumDirtBugs func_176766_a(int p_176766_0_)
    {
        if (p_176766_0_ < 0 || p_176766_0_ >= field_176789_r.length)
        {
            p_176766_0_ = 0;
        }

        return field_176789_r[p_176766_0_];
    }

    public static EnumDirtBugs func_176764_b(int p_176764_0_)
    {
        if (p_176764_0_ < 0 || p_176764_0_ >= field_176790_q.length)
        {
            p_176764_0_ = 0;
        }

        return field_176790_q[p_176764_0_];
    }

    public String toString()
    {
        return this.string;
    }

    public String getName()
    {
        return this.name;
    }

    static
    {
        EnumDirtBugs[] var0 = values();
        int var1 = var0.length;

        for (int var2 = 0; var2 < var1; ++var2)
        {
            EnumDirtBugs var3 = var0[var2];
            field_176790_q[var3.func_176765_a()] = var3;
            field_176789_r[var3.getIngotDamage()] = var3;
        }
    }
}