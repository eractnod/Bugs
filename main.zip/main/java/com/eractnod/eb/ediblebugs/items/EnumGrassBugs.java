package com.eractnod.eb.ediblebugs.items;

import net.minecraft.util.IStringSerializable;

public enum EnumGrassBugs implements IStringSerializable
{
    GRASSHOPPER(0, 3, "grasshopper", "grasshopper"),
    LOCUST(1, 2, "locust", "locust"),
    CRICKET(2, 1, "cricket", "cricket"),
    APHID(3, 0, "aphid", "aphid");
    
    public static final int GRASSHOPPER_META = EnumGrassBugs.GRASSHOPPER.getIngotDamage();
    public static final int LOCUST_META = EnumGrassBugs.LOCUST.getIngotDamage();
    public static final int CRICKET_META = EnumGrassBugs.CRICKET.getIngotDamage();
    public static final int APHID_META = EnumGrassBugs.APHID.getIngotDamage();

    
    private static final EnumGrassBugs[] field_176790_q = new EnumGrassBugs[values().length];
    private static final EnumGrassBugs[] field_176789_r = new EnumGrassBugs[values().length];
    private final int meta;
    private final int damage;
    private final String name;
    private final String string;

    private EnumGrassBugs(int meta, int damage, String name, String string)
    {
        this.meta = meta;
        this.damage = damage;
        this.name = name;
        this.string = string;
    }

    public int func_176765_a()
    {
        return this.meta;
    }

    public int getIngotDamage()
    {
        return this.damage;
    }

    public String func_176762_d()
    {
        return this.string;
    }

   
    public static EnumGrassBugs func_176766_a(int p_176766_0_)
    {
        if (p_176766_0_ < 0 || p_176766_0_ >= field_176789_r.length)
        {
            p_176766_0_ = 0;
        }

        return field_176789_r[p_176766_0_];
    }

    public static EnumGrassBugs func_176764_b(int p_176764_0_)
    {
        if (p_176764_0_ < 0 || p_176764_0_ >= field_176790_q.length)
        {
            p_176764_0_ = 0;
        }

        return field_176790_q[p_176764_0_];
    }

    public String toString()
    {
        return this.string;
    }

    public String getName()
    {
        return this.name;
    }

    static
    {
        EnumGrassBugs[] var0 = values();
        int var1 = var0.length;

        for (int var2 = 0; var2 < var1; ++var2)
        {
            EnumGrassBugs var3 = var0[var2];
            field_176790_q[var3.func_176765_a()] = var3;
            field_176789_r[var3.getIngotDamage()] = var3;
        }
    }
}