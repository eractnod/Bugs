package com.eractnod.eb.ediblebugs.items;

import net.minecraft.item.ItemFood;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class EBFoodItemClass extends ItemFood
{

	public EBFoodItemClass(int heal, float saturation, boolean wolfFood) {
		
		super(heal, saturation, wolfFood);
		
		setCreativeTab(EdibleBugs.tabEdibleBugs);
		
		
	}

}
