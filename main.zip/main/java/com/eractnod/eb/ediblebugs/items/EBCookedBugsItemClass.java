package com.eractnod.eb.ediblebugs.items;

import java.util.List;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class EBCookedBugsItemClass extends ItemFood {

	public EBCookedBugsItemClass(int heal, float saturation, boolean wolfFood)
	{
		super(heal, saturation, wolfFood);
		this.setHasSubtypes(true);
		this.setMaxDamage(0);
		this.setCreativeTab(EdibleBugs.tabEdibleBugs);
		
	}
	
	public String getUnlocalizedName(ItemStack stack)
    {
        int i = stack.getMetadata();
        return super.getUnlocalizedName() + "." + EnumCookedBugs.func_176766_a(i).func_176762_d();
    }

	 @SideOnly(Side.CLIENT)
	 @Override
	 public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> subItems)
    {
		 if (this.isInCreativeTab(tab))
		 {
			 for (int i = 0; i < 17; ++i)
			 {
				 subItems.add(new ItemStack(this, 1, i));
			 }
		 }
    }

}
