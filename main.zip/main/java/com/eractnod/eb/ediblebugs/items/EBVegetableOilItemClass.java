package com.eractnod.eb.ediblebugs.items;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class EBVegetableOilItemClass extends Item{
	
	public EBVegetableOilItemClass() {
		super();
		
		this.setMaxStackSize(64);
		setCreativeTab(EdibleBugs.tabEdibleBugs);
		
	}
 
}
