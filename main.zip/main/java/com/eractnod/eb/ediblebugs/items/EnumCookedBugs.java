package com.eractnod.eb.ediblebugs.items;

import net.minecraft.util.IStringSerializable;

public enum EnumCookedBugs implements IStringSerializable
{
    CGRASSHOPPER(0, 16, "cgrasshopper", "cgrasshopper"),
    CLOCUST(1, 15, "clocust", "clocust"),
    CCRICKET(2, 14, "ccricket", "ccricket"),
    CAPHID(3, 13, "caphid", "caphid"),
    CFIREANT(4, 12, "cfireant", "cfireant"),
    CSLUG(5, 11, "cslug", "cslug"),
    CSOWBUG(6, 10, "csowbug", "csowbug"),
    CDUNGBEETLE(7, 9, "cdungbeetle", "cdungbeetle"),
    CCARPENTERANT(8, 8, "ccarpenterant", "ccarpenterant"),
    CWOODTERMITE(9, 7, "cwoodtermite", "cwoodtermite"),
    CJUMIL(10, 6, "cjumil", "cjumil"),
    CWITCHETTYGRUB(11, 5, "cwitchettygrub", "cwitchettygrub"),
    CTERMITE(12, 4, "ctermite", "ctermite"),
    CCAMELSPIDER(13, 3, "ccamelspider", "ccamelspider"),
    CSCORPION(14, 2, "cscorpion", "cscorpion"),
    CCENTIPEDE(15, 1, "ccentipede", "ccentipede"),
    CSCARAB(16, 0, "cscarab", "cscarab");
    
    public static final int CGRASSHOPPER_META = EnumCookedBugs.CGRASSHOPPER.getIngotDamage();
    public static final int CLOCUST_META = EnumCookedBugs.CLOCUST.getIngotDamage();
    public static final int CCRICKET_META = EnumCookedBugs.CCRICKET.getIngotDamage();
    public static final int CAPHID_META = EnumCookedBugs.CAPHID.getIngotDamage();
    public static final int CFIREANT_META = EnumCookedBugs.CFIREANT.getIngotDamage();
    public static final int CSLUG_META = EnumCookedBugs.CSLUG.getIngotDamage();
    public static final int CSOWBUG_META = EnumCookedBugs.CSOWBUG.getIngotDamage();
    public static final int CDUNGBEETLE_META = EnumCookedBugs.CDUNGBEETLE.getIngotDamage();
    public static final int CCARPENTERANT_META = EnumCookedBugs.CCARPENTERANT.getIngotDamage();
    public static final int CWOODTERMITE_META = EnumCookedBugs.CWOODTERMITE.getIngotDamage();
    public static final int CJUMIL_META = EnumCookedBugs.CJUMIL.getIngotDamage();
    public static final int CWITCHETTYGRUB_META = EnumCookedBugs.CWITCHETTYGRUB.getIngotDamage();
    public static final int CTERMITE_META = EnumCookedBugs.CTERMITE.getIngotDamage();
    public static final int CCAMELSPIDER_META = EnumCookedBugs.CCAMELSPIDER.getIngotDamage();
    public static final int CSCORPION_META = EnumCookedBugs.CSCORPION.getIngotDamage();
    public static final int CCENTIPEDE_META = EnumCookedBugs.CCENTIPEDE.getIngotDamage();
    public static final int CSCARAB_META = EnumCookedBugs.CSCARAB.getIngotDamage();

    private static final EnumCookedBugs[] field_176790_q = new EnumCookedBugs[values().length];
    private static final EnumCookedBugs[] field_176789_r = new EnumCookedBugs[values().length];
    private final int meta;
    private final int damage;
    private final String name;
    private final String string;

    private EnumCookedBugs(int meta, int damage, String name, String string)
    {
        this.meta = meta;
        this.damage = damage;
        this.name = name;
        this.string = string;
    }

    public int func_176765_a()
    {
        return this.meta;
    }

    public int getIngotDamage()
    {
        return this.damage;
    }

    public String func_176762_d()
    {
        return this.string;
    }

   
    public static EnumCookedBugs func_176766_a(int p_176766_0_)
    {
        if (p_176766_0_ < 0 || p_176766_0_ >= field_176789_r.length)
        {
            p_176766_0_ = 0;
        }

        return field_176789_r[p_176766_0_];
    }

    public static EnumCookedBugs func_176764_b(int p_176764_0_)
    {
        if (p_176764_0_ < 0 || p_176764_0_ >= field_176790_q.length)
        {
            p_176764_0_ = 0;
        }

        return field_176790_q[p_176764_0_];
    }

    public String toString()
    {
        return this.string;
    }

    public String getName()
    {
        return this.name;
    }

    static
    {
        EnumCookedBugs[] var0 = values();
        int var1 = var0.length;

        for (int var2 = 0; var2 < var1; ++var2)
        {
            EnumCookedBugs var3 = var0[var2];
            field_176790_q[var3.func_176765_a()] = var3;
            field_176789_r[var3.getIngotDamage()] = var3;
        }
    }
}