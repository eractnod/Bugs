package com.eractnod.eb.ediblebugs.items;

import java.util.List;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class EBSandBugsItemClass extends ItemFood {

    private int potionId;
    private int potionDuration;
    private int potionAmplifier;
    private float potionEffectProbability;
    
    
	public EBSandBugsItemClass(int heal, float saturation, boolean wolfFood)
	{
		super(heal, saturation, wolfFood);
		this.setHasSubtypes(true);
		this.setMaxDamage(0);
		this.setCreativeTab(EdibleBugs.tabEdibleBugs);
		
	}

	public String getUnlocalizedName(ItemStack stack)
    {
        int i = stack.getMetadata();
        return super.getUnlocalizedName() + "." + EnumSandBugs.func_176766_a(i).func_176762_d();
    }
 	 
	 @SideOnly(Side.CLIENT)
	 @Override
	 public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> subItems)
	    {
		 if (this.isInCreativeTab(tab))
		 {
	        for (int i = 0; i < 4; ++i)
	        {
	        	subItems.add(new ItemStack(this, 1, i));
	        }
		 }
	    }

	    protected void onFoodEaten(ItemStack itemStack, World world, EntityPlayer player)
	    {
	    	this.setPotionEffect(9, 6, 1, 0.4F);
	    
	        if (!world.isRemote && this.potionId > 0 && world.rand.nextFloat() < this.potionEffectProbability)
	        {
	            player.addPotionEffect(new PotionEffect(MobEffects.POISON, this.potionDuration * 6, this.potionAmplifier));
	        }
	    }
	    /**
	     * sets a potion effect on the item. Args: int potionId, int duration (will be multiplied by 20), int amplifier,
	     * float probability of effect happening
	     */
	    public ItemFood setPotionEffect(int potionID, int duration, int amplifier, float probability)
	    {

	        this.potionId = potionID;
	        this.potionDuration = duration;
	        this.potionAmplifier = amplifier;
	        this.potionEffectProbability = probability;
	        return this;
	    }

}
