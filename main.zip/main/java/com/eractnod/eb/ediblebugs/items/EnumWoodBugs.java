package com.eractnod.eb.ediblebugs.items;

import net.minecraft.util.IStringSerializable;

public enum EnumWoodBugs implements IStringSerializable
{
    CARPENTERANT(0, 3, "carpenterant", "carpenterant"),
    WOODTERMITE(1, 2, "woodtermite", "woodtermite"),
    JUMIL(2, 1, "jumil", "jumil"),
    WITCHETTYGRUB(3, 0, "witchettygrub", "witchettygrub");
    
    public static final int CARPENTERANT_META = EnumWoodBugs.CARPENTERANT.getIngotDamage();
    public static final int WOODTERMITE_META = EnumWoodBugs.WOODTERMITE.getIngotDamage();
    public static final int JUMIL_META = EnumWoodBugs.JUMIL.getIngotDamage();
    public static final int WITCHETTYGRUB_META = EnumWoodBugs.WITCHETTYGRUB.getIngotDamage();

    
    private static final EnumWoodBugs[] field_176790_q = new EnumWoodBugs[values().length];
    private static final EnumWoodBugs[] field_176789_r = new EnumWoodBugs[values().length];
    private final int meta;
    private final int damage;
    private final String name;
    private final String string;

    private EnumWoodBugs(int meta, int damage, String name, String string)
    {
        this.meta = meta;
        this.damage = damage;
        this.name = name;
        this.string = string;
    }

    public int func_176765_a()
    {
        return this.meta;
    }

    public int getIngotDamage()
    {
        return this.damage;
    }

    public String func_176762_d()
    {
        return this.string;
    }

   
    public static EnumWoodBugs func_176766_a(int p_176766_0_)
    {
        if (p_176766_0_ < 0 || p_176766_0_ >= field_176789_r.length)
        {
            p_176766_0_ = 0;
        }

        return field_176789_r[p_176766_0_];
    }

    public static EnumWoodBugs func_176764_b(int p_176764_0_)
    {
        if (p_176764_0_ < 0 || p_176764_0_ >= field_176790_q.length)
        {
            p_176764_0_ = 0;
        }

        return field_176790_q[p_176764_0_];
    }

    public String toString()
    {
        return this.string;
    }

    public String getName()
    {
        return this.name;
    }

    static
    {
        EnumWoodBugs[] var0 = values();
        int var1 = var0.length;

        for (int var2 = 0; var2 < var1; ++var2)
        {
            EnumWoodBugs var3 = var0[var2];
            field_176790_q[var3.func_176765_a()] = var3;
            field_176789_r[var3.getIngotDamage()] = var3;
        }
    }
}