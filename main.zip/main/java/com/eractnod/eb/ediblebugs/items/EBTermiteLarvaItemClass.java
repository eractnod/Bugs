package com.eractnod.eb.ediblebugs.items;

import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.blocks.TermiteBlockClass;
import com.eractnod.eb.ediblebugs.common.EBVarInit;

public class EBTermiteLarvaItemClass extends Item{
	public EBTermiteLarvaItemClass() {
		super();
		
		setMaxStackSize(64);
		setCreativeTab(EdibleBugs.tabEdibleBugs);
		
	}

	/**
     * Callback for item usage. If the item does something special on right clicking, he will have one of those. Return
     * True if something happen and false if it don't. This is for ITEMS, not BLOCKS
     */
	@Override
    public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
		ItemStack stack = player.getHeldItem(hand);
		
		if (world.getBlockState(pos) != Blocks.DIRT.getDefaultState()){
    		return EnumActionResult.FAIL;
    	}
 
    	world.setBlockState(pos, EBVarInit.termiteBlock.getDefaultState().withProperty(TermiteBlockClass.VARIANT_PROP, TermiteBlockClass.EnumType.ACTIVE));
        //Looks like this will subtact 1 from itemstack
    	stack.shrink(1);
        
       
        return EnumActionResult.PASS;
    }

	   /**
     * allows items to add custom lines of information to the mouseover description
     */
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced)
    {
    	tooltip.add(TextFormatting.GREEN + "Right click a dirt block with this larve.");
    	tooltip.add(TextFormatting.GREEN + "This will generate a termite mound that will grow over time.");

    }
    
}
