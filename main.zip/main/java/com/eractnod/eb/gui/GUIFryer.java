package com.eractnod.eb.gui;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import org.lwjgl.opengl.GL11;

import com.eractnod.eb.container.ContainerFryer;
import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityEBFryer;


@SideOnly(Side.CLIENT)
public class GUIFryer extends GuiContainer
{
    //private static final ResourceLocation furnaceGuiTextures = new ResourceLocation("textures/gui/container/furnace.png");
    private static final ResourceLocation fryerGuiTextures = new ResourceLocation(EdibleBugs.MODID + ":textures/gui/container/fryer.png");
    
    private TileEntityEBFryer fryerInventory;

    public GUIFryer(InventoryPlayer par1InventoryPlayer, TileEntityEBFryer par2TileEntityFurnace)
    {
        super(new ContainerFryer(par1InventoryPlayer, par2TileEntityFurnace));
        this.fryerInventory = par2TileEntityFurnace;
    }

    /**
    * Draws the screen and all the components in it.
    */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
    	this.drawDefaultBackground();
    	super.drawScreen(mouseX, mouseY, partialTicks);
    	this.renderHoveredToolTip(mouseX, mouseY);
    }

    /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void drawGuiContainerForegroundLayer(int par1, int par2)
    {
        String s = this.fryerInventory.isInvNameLocalized() ? this.fryerInventory.getInvName() : I18n.format(this.fryerInventory.getInvName());
        this.fontRenderer.drawString(s, this.xSize / 2 - this.fontRenderer.getStringWidth(s) / 2, 6, 0000000);
        this.fontRenderer.drawString(I18n.format("container.inventory"), 8, this.ySize - 96 + 2, 0000000);
    }

    /**
     * Draw the background layer for the GuiContainer (everything behind the items)
     */
    protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3)
    {
    	//need to change this once a gui is made
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        //this.mc.getTextureManager().bindTexture(furnaceGuiTextures);
        this.mc.getTextureManager().bindTexture(fryerGuiTextures);
        int k = (this.width - this.xSize) / 2;
        int l = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
        int i1;

        if (this.fryerInventory.isBurning())
        {
            i1 = this.fryerInventory.getBurnTimeRemainingScaled(12);
            this.drawTexturedModalRect(k + 56, l + 36 + 12 - i1, 176, 12 - i1, 14, i1 + 2);
        }

        i1 = this.fryerInventory.getCookProgressScaled(24);
        this.drawTexturedModalRect(k + 79, l + 34, 176, 14, i1 + 1, 16);
    }
}
