package com.eractnod.eb.gui;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

import com.eractnod.eb.container.ContainerBugZapper;
import com.eractnod.eb.container.ContainerFryer;
import com.eractnod.eb.ediblebugs.common.EBVarInit;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityBugZapper;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityEBFryer;

public class EBGuiHandler implements IGuiHandler{

	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		
		TileEntity tile_entity = world.getTileEntity(new BlockPos(x, y, z));
		ItemStack equipped;
		 
		switch (ID){
		case EBVarInit.guiIDFryer:
			if(tile_entity instanceof TileEntityEBFryer){
				return new ContainerFryer(player.inventory, (TileEntityEBFryer)tile_entity);
			}
		case EBVarInit.guiIDBugZapper:
			if(tile_entity instanceof TileEntityBugZapper){
				return new ContainerBugZapper(player.inventory, (TileEntityBugZapper)tile_entity);
			}
		}
			
		return null;
	}

	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		
		TileEntity tile_entity = world.getTileEntity(new BlockPos(x, y, z));
		ItemStack equipped;
		
		switch (ID){
		case EBVarInit.guiIDFryer:
			if(tile_entity instanceof TileEntityEBFryer){
				return new GUIFryer(player.inventory, (TileEntityEBFryer)tile_entity);
			}
		case EBVarInit.guiIDBugZapper:
			if(tile_entity instanceof TileEntityBugZapper){
				return new GUIBugZapper(player.inventory, (TileEntityBugZapper)tile_entity);
			}
		}
		
		return null;
	}

}
