package com.eractnod.eb.gui;

import org.lwjgl.opengl.GL11;

import com.eractnod.eb.container.ContainerBugZapper;
import com.eractnod.eb.container.ContainerFryer;
import com.eractnod.eb.ediblebugs.EdibleBugs;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityBugZapper;
import com.eractnod.eb.ediblebugs.tileentity.TileEntityEBFryer;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.util.ResourceLocation;

public class GUIBugZapper extends GuiContainer{

	 private static final ResourceLocation zapperGuiTextures = new ResourceLocation(EdibleBugs.MODID + ":textures/gui/container/bugzappergui.png");
	 private TileEntityBugZapper zapperInventory;

	   public GUIBugZapper(InventoryPlayer inventoryPlayer, TileEntityBugZapper tileentity)
	    {
	        super(new ContainerBugZapper(inventoryPlayer, tileentity));
	        this.zapperInventory = tileentity;
	    }

   /**
   * Draws the screen and all the components in it.
   */
   @Override
   public void drawScreen(int mouseX, int mouseY, float partialTicks)
   {
	   this.drawDefaultBackground();
	   super.drawScreen(mouseX, mouseY, partialTicks);
	   this.renderHoveredToolTip(mouseX, mouseY);
   }

	  
	@Override
	protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {

        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        this.mc.getTextureManager().bindTexture(zapperGuiTextures);
        int k = (this.width - this.xSize) / 2;
        int l = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(k, l, 0, 0, this.xSize, this.ySize);
 
    }

	 /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void drawGuiContainerForegroundLayer(int par1, int par2)
    {
        String s = "Termite Zapper";
        this.fontRenderer.drawString(s, this.xSize / 2 - this.fontRenderer.getStringWidth(s) / 2, 6, 0000000);
        this.fontRenderer.drawString(I18n.format("container.inventory"), 8, this.ySize - 96 + 2, 0000000);
    }
}
